#include <bits/stdc++.h>
using namespace std;
int main() 
{
    int n;
    cin >> n;
    vector<long long> a(n);
    for (int i = 0; i < n; i++) cin >> a[i];
    sort(a.begin(), a.end());
    long long ket_qua = llabs(a[1] - a[0]);
    for (int i = 2; i < n; i++) 
    {
        long long hieu = llabs(a[i] - a[i - 1]);
        if (hieu < ket_qua) ket_qua = hieu;
    }
    cout << ket_qua;
}