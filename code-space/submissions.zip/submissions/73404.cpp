#include <bits/stdc++.h>
using namespace std;
using ll = long long;
ll C3(ll n) 
{
    if (n < 3) return 0;
    return n * (n - 1) * (n - 2) / 6;
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll n;
    cin >> n;
    ll cntNot = 0;
    for (ll i = 0; i < n; i++) 
    {
        long long x;
        cin >> x;
        if (x % 5 != 0)
            cntNot++;
    }
    cout << C3(n) - C3(cntNot);
}