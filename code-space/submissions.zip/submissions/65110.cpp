#include <bits/stdc++.h>
using namespace std;
void solve() 
{
    int n;
    cin >> n;
    vector<long long> a(n);
    for (int i = 0; i < n; ++i) 
    {
        cin >> a[i];
    }
    sort(a.begin(), a.end());
    long long count = 0;
    for (int i = 0; i < n - 2; ++i) 
    {
        for (int j = i + 1; j < n - 1; ++j) 
        {
            long long target = a[n-1] - a[i] - a[j];
            auto it = upper_bound(a.begin() + j + 1, a.end() - 1, target);
            count += (a.end() - 1 - it);
        }
    }
    cout << count << endl;
}
int main() 
{
    int t;
    cin >> t;
    while (t--) 
    {
        solve();
    }
    return 0;
}