#include <bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int soLuongPhanTu, doDaiDoan;
    cin >> soLuongPhanTu >> doDaiDoan;
    queue<long long> cuaSo;
    long long tongHienTai = 0;
    long long tongNhoNhat = LLONG_MAX;
    for (int chiSo = 1; chiSo <= soLuongPhanTu; chiSo++) {
        long long giaTri;
        cin >> giaTri;
        cuaSo.push(giaTri);
        tongHienTai += giaTri;
        if ((int)cuaSo.size() > doDaiDoan) {
            tongHienTai -= cuaSo.front();
            cuaSo.pop();
        }
        if ((int)cuaSo.size() == doDaiDoan) {
            tongNhoNhat = min(tongNhoNhat, tongHienTai);
        }
    }
    cout << tongNhoNhat;
}