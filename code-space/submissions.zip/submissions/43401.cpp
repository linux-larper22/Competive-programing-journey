#include <bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n, k;
    cin >> n >> k;
    int val[100005];
    int i;
    int max_val = 0;
    for (i = 1; i <= n; i++) {
        cin >> val[i];
        if (val[i] > max_val) max_val = val[i];
    }
    int count = 0;
    for (int v = max_val; v >= 1 && count < k; v--) {
        for (i = 1; i <= n && count < k; i++) {
            if (val[i] == v) {
                if (count > 0) cout << " ";
                cout << i;
                count++;
            }
        }
    }
}