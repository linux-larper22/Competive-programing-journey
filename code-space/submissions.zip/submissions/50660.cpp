#include<bits/stdc++.h>
using namespace std;
const int N = 1e6 + 5;
int n, a, d, ans;
int main() 
{
ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
cin>>n;
for(int i=1; i <= n; i++) { cin>>a[i]; d[a[i]]++; }
//d[x] = ? so luong so hang trong day bang x
//ans[x] --> so luong so hang trong day chia het cho x
ans[1] = n;
for (int x = 2; x < N; x++) {
for (int t = x; t < N; t += x) ans[x] += d[t];
}
//--N/2 + N/3 + N/4 +...+ N/N
//x = a[1]--> co bao nhieu so chia het cho a[1] ans[x]
for (int i = 1; i <= n; i++)
cout<<ans[a[i]]<<" ";
}