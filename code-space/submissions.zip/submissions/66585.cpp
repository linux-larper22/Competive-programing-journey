#include <bits/stdc++.h>
using namespace std;

























int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(0);

    int n; cin >> n;
    vector<long long> a(n);
    for (auto &x : a) cin >> x;

    long long g = 0;
    for (int i = 1; i < n; i++) {
        g = __gcd(g, abs(a[i] - a[0]));
    }

    cout << g;
}