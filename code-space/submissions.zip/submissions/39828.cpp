#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    int C;
    cin >> C;
    int a[3][100005]; // chỉ dùng hàng 1 và 2

    for (int i = 1; i <= 2; i++)
        for (int j = 1; j <= C; j++)
            cin >> a[i][j];

    int ans = 0;

    // Bước 1: mỗi tam giác đen có 3 cạnh
    for (int i = 1; i <= 2; i++)
        for (int j = 1; j <= C; j++)
            if (a[i][j] == 1)
                ans += 3;

    // Bước 2: trừ đi các cạnh chung giữa hai tam giác đen
    for (int j = 1; j <= C; j++) {
        // Trên - Dưới cùng cột
        if (a[1][j] == 1 && a[2][j] == 1)
            ans -= 2;

        // Chéo phải: trên j với dưới j+1
        if (j < C && a[1][j] == 1 && a[2][j + 1] == 1)
            ans -= 2;

        // Chéo phải: dưới j với trên j+1
        if (j < C && a[2][j] == 1 && a[1][j + 1] == 1)
            ans -= 2;
    }

    cout << ans;
    return 0;
}