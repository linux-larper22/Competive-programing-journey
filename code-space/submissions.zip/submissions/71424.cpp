#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const ll INF = (ll)4e18;

struct Line{
    ll m, b;
    ll get(ll x){ return m*x + b; }
};

struct Node{
    Line line;
    Node *l = nullptr, *r = nullptr;
    Node(Line _l): line(_l) {}
};

ll L = 0, R = 1000000000;

void add_line(Node* &node, Line nw, ll l=L, ll r=R){
    if(!node){
        node = new Node(nw);
        return;
    }

    ll mid = (l+r)/2;

    bool lef = nw.get(l) < node->line.get(l);
    bool m   = nw.get(mid) < node->line.get(mid);

    if(m) swap(node->line, nw);

    if(r-l == 0) return;

    if(lef != m)
        add_line(node->l, nw, l, mid);
    else
        add_line(node->r, nw, mid+1, r);
}

ll query(Node* node, ll x, ll l=L, ll r=R){
    if(!node) return INF;

    ll res = node->line.get(x);
    if(l==r) return res;

    ll mid = (l+r)/2;
    if(x <= mid)
        return min(res, query(node->l, x, l, mid));
    else
        return min(res, query(node->r, x, mid+1, r));
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;

    vector<ll>a(n+1), pref(n+1,0);
    for(int i=1;i<=n;i++){
        cin >> a[i];
        pref[i] = pref[i-1] + a[i];
    }

    vector<ll> dp_prev(n+1, INF), dp_cur(n+1, INF);
    dp_prev[0] = 0;

    for(int kk=1; kk<=k; kk++){
        Node* root = nullptr;

        add_line(root, {0, dp_prev[0]});

        for(int i=1;i<=n;i++){
            ll best = query(root, pref[i]);
            dp_cur[i] = kk * pref[i] + best;

            add_line(root, {-pref[i], dp_prev[i]});
        }

        dp_prev = dp_cur;
    }

    cout << dp_prev[n];
}