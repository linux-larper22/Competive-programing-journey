#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while(t--) {
        long long n;
        int a, b, c;
        cin >> n >> a >> b >> c;

        long long sum3 = a + b + c;
        long long fullCycles = n / sum3;
        long long distance = fullCycles * sum3;
        long long day = fullCycles * 3;
        int arr[3] = {a, b, c};
        for(int i = 0; i < 3; i++) {
            distance += arr[i];
            day++;
            if(distance >= n) {
                cout << day << '\n';
                break;
            }
        }
    }
    return 0;
}