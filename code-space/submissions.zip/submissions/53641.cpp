#include <bits/stdc++.h>
using namespace std;
int main() 
{
    long long soDong5, soDong10, soDong20, soDong50, soTien;
    cin >> soDong5 >> soDong10 >> soDong20 >> soDong50 >> soTien;
    long long totNhat = LLONG_MAX;
    long long dapAn[4] = {};
    for (long long dung50 = 0; dung50 <= soDong50 && dung50 * 50 <= soTien; dung50++) {
        for (long long dung20 = 0; dung20 <= soDong20 && dung50 * 50 + dung20 * 20 <= soTien; dung20++) {
            long long conLai = soTien - dung50 * 50 - dung20 * 20;
            long long dung10 = min(soDong10, conLai / 10);
            conLai -= dung10 * 10;
            long long dung5 = min(soDong5, conLai / 5);
            conLai -= dung5 * 5;
            if (conLai == 0) 
            {
                long long tongXu = dung5 + dung10 + dung20 + dung50;
                if (tongXu < totNhat) 
                {
                    totNhat = tongXu;
                    dapAn[0] = dung5;
                    dapAn[1] = dung10;
                    dapAn[2] = dung20;
                    dapAn[3] = dung50;
                }
            }
        }
    }
    if (totNhat == LLONG_MAX) 
    {
        cout << -1;
    } else {
        cout << dapAn[0] << " " << dapAn[1] << " "
             << dapAn[2] << " " << dapAn[3] << " " << totNhat;
    }
}