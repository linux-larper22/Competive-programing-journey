#include <bits/stdc++.h>
using namespace std;
bool laSquareFree(long long x) 
{
    for (long long p = 2; p * p <= x; p++) 
    {
        int dem = 0;
        while (x % p == 0) 
        {
            x /= p;
            dem++;
            if (dem >= 2) return false; 
        }
    }
    return true;
}
int main() 
{
    long long L, R;
    cin >> L >> R;
    int n = R - L + 1;
    vector<long long> a(n);
    vector<bool> squareFree(n);
    for (int i = 0; i < n; i++) 
    {
        a[i] = L + i;
        squareFree[i] = laSquareFree(a[i]);
    }
    long long demCap = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) 
        {
            if (!(squareFree[i] && squareFree[j] && gcd(a[i], a[j]) == 1))
                demCap++;
        }
    }
    cout << demCap;
}