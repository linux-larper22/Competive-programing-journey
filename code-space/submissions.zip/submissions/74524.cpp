#include <bits/stdc++.h>
using namespace std;
const long long MOD = 1000000007;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    long long dp[3]={1,0,0};
    for(int i=0;i<n;i++)
    {
        int x;
        cin >> x;
        long long ndp[3];
        for(int j=0;j<3;j++) ndp[j]=dp[j];
        for(int r=0;r<3;r++)
        {
            ndp[(r+x)%3] =
                (ndp[(r+x)%3] + dp[r]) % MOD;
        }
        for(int j=0;j<3;j++) dp[j]=ndp[j];
    }
    cout << (dp[0]-1+MOD)%MOD;
}