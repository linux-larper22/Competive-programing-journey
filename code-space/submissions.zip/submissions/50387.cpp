#include <iostream>
using namespace std;
int main() 
{
    int n;
    long long S;
    cin >> n >> S;
    long long sum = 0, x;
    int cnt = 1;
    for (int i = 0; i < n; i++) 
    {
        cin >> x;
        if (sum + x > S) 
        {
            cnt++;
            sum = x;
        } else sum += x;
    }
    cout << cnt;
}