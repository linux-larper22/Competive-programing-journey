#include <bits/stdc++.h>
using namespace std;

long long C2(long long x) { return x * (x - 1) / 2; }
long long C3(long long x) { return x * (x - 1) * (x - 2) / 6; }

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while(t--) {
        int n;
        cin >> n;
        vector<long long> a(n);
        map<long long,int> freq;
        for(int i=0;i<n;i++) {
            cin >> a[i];
            freq[a[i]]++;
        }
        sort(a.begin(), a.end());

        long long x = a[n-3];
        long long y = a[n-2];
        long long z = a[n-1];

        if(x + y <= z) {
            cout << 0 << "\n";
            continue;
        }

        long long cnt_x = freq[x];
        long long cnt_y = freq[y];
        long long cnt_z = freq[z];

        long long res = 0;
        if(x == y && y == z) {
            res = C3(cnt_x);
        } else if(x == y) {
            res = C2(cnt_x) * cnt_z;
        } else if(y == z) {
            res = cnt_x * C2(cnt_y);
        } else {
            res = cnt_x * cnt_y * cnt_z;
        }

        cout << res << "\n";
    }
}