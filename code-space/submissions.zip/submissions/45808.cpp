#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int T;
    cin >> T;
    while (T--) {
        long long a, b, c, d;
        cin >> a >> b >> c >> d;
        cout << max(
                    max(llabs(2*a - 3*c), llabs(2*a - 3*d)),
                    max(llabs(2*b - 3*c), llabs(2*b - 3*d))
               ) << '\n';
    }
}