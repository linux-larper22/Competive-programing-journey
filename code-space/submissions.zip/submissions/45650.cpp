#include<bits/stdc++.h>
using namespace std;
int main(){
    long long x1, y1, x2, y2, x3, y3;
    cin>>x1>>y1;
    cin>>x2>>y2;
    cin>>x3>>y3
    long long u = max({x1, x2, x3, 1LL});
    long long v = min({y1, y2, y3});
    if(u > v) cout<<0;
    else cout<<v-u+1;
    return 0;
}