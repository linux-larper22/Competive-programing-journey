#include <bits/stdc++.h>
using namespace std;
using ll = long long;
map<ll, ll> factor(ll x) 
{
    map<ll, ll> mp;
    for (ll i = 2; i * i <= x; i++) 
    {
        while (x % i == 0) {
            mp[i]++;
            x /= i;
        }
    }
    if (x > 1) mp[x]++;
    return mp;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int T; cin >> T;
    while (T--) {
        ll a, b; cin >> a >> b;

        auto fa = factor(a);
        auto fb = factor(b);

        for (auto &x : fb) fa[x.first] += x.second;

        ll res = 1;
        for (auto x : fa) res *= (x.second + 1);

        cout << res << "\n";
    }
}