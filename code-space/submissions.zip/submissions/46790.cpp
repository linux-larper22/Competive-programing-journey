#include <bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int soLuongPhanTu, soLuongXoa;
    cin >> soLuongPhanTu >> soLuongXoa;
    long long* cuaSo = new long long[soLuongXoa]; // mảng vòng
    int dau = 0, kichThuoc = 0;
    long long tongToanBo = 0;
    long long tongCuaSo = 0;
    long long tongXoaNhoNhat = LLONG_MAX;
    for (int chiSo = 1; chiSo <= soLuongPhanTu; chiSo++) {
        long long giaTri;
        cin >> giaTri;
        tongToanBo += giaTri;
        if (kichThuoc < soLuongXoa) {
            cuaSo[kichThuoc++] = giaTri;
            tongCuaSo += giaTri;
        } else {
            tongCuaSo -= cuaSo[dau];
            cuaSo[dau] = giaTri;
            tongCuaSo += giaTri;
            dau = (dau + 1) % soLuongXoa;
        }
       if (kichThuoc == soLuongXoa) {
            tongXoaNhoNhat = min(tongXoaNhoNhat, tongCuaSo);
        }
    }
    long long ketQua = tongToanBo - tongXoaNhoNhat;
    cout << ketQua;
}