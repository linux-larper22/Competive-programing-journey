#include <bits/stdc++.h>
using namespace std;

bool isPrime(int x){
    if(x < 2) return false;
    for(int i = 2; i*i <= x; i++)
        if(x % i == 0) return false;
    return true;
}

int digitSum(int x){
    int sum = 0;
    while(x){
        sum += x % 10;
        x /= 10;
    }
    return sum;
}

int main(){
    int n;
    cin >> n;
    vector<bool> prime(n+1, true);
    prime[0] = prime[1] = false;
    for(int i = 2; i*i <= n; i++)
        if(prime[i])
            for(int j = i*i; j <= n; j += i)
                prime[j] = false;
    
    int ans = 0;
    for(int i = 2; i <= n; i++)
        if(prime[i] && isPrime(digitSum(i)))
            ans++;
    cout << ans << endl;
    return 0;
}