#include<bits/stdc++.h>
using namespace std;
long long n, m, sum[10003], ans[10002];
pair<long long , int> a[10004];
int main(){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cin>>n>>m;
    for(int i = 1; i <= n; i++) {
        cin>>a[i].first;
        a[i].second = i;
    }
    sort(a+1, a+1+n);
    for(int i = 1; i <= n; i++) sum[i] = sum[i-1] + a[i].first;
    for(int i = n; i >= 1; i--){
        long long x = i*a[i].first - sum[i];
        if(m >= x){
            m -= x;
            long long e = m/i;
            for(int t = 1; t <= i; t++) a[t].first = e + a[i].first;
            m = m%i;
            sort(a+1, a+1+i);
            for(int t = 1; t <= m; t++) a[t].first++;
            break;
        }
    }
    for(int i = 1; i <= n; i++){
        int t = a[i].second;
        ans[t] = a[i].first;
    }
    cout<<*min_element(ans+1, ans+1+n)<<endl;
    for(int i = 1; i <= n; i++) cout<<ans[i]<<" ";
}