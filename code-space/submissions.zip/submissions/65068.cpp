#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<long long> a(n), odd, even;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        if (a[i] % 2) odd.push_back(a[i]);
        else even.push_back(a[i]);
    }
    sort(odd.begin(), odd.end());           
    sort(even.rbegin(), even.rend());
    int i1 = 0, i2 = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] % 2) cout << odd[i1++] << " ";
        else cout << even[i2++] << " ";
    }
}