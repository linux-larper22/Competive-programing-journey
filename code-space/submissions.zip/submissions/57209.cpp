#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n;
    cin >> n;
    long long ans = 0;
    for (long long i = 1; i * i <= n; i++) 
    {
        long long q = n / i;
        ans += q;
        if (i != q) ans += (q - i);
    }
    cout << ans;
}