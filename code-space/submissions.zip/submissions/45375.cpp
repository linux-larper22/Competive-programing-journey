#include <bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long x1, y1, x2, y2, x3, y3;
    cin >> x1 >> y1;
    cin >> x2 >> y2;
    cin >> x3 >> y3;
    long long L = max({x1, x2, x3});
    long long R = min({y1, y2, y3});
    if (L > R) cout << 0;
    else cout << R - L + 1;
}