#include <bits/stdc++.h>
using namespace std;
bool isPrime(long long x)
{
    if (x < 2) return false;
    if (x % 2 == 0) return x == 2;
    for(long long i = 3; i * i <= x; i += 2)
        if(x % i == 0)
            return false;

    return true;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
    vector<long long> a(n);
    for(int i = 0; i < n; i++)
        cin >> a[i];
    long long ans = 0;
    for(int i = 0; i < n; i++)
        for(int j = i + 1; j < n; j++)
            if(isPrime(a[i] + a[j]))
                ans++;
    cout << ans;
}