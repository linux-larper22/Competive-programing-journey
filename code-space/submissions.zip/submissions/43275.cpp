#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N;
    cin >> N;
    int L[1000000];      
    int cnt[2001] = {0};  

    for(int i = 0; i < N; i++) {
        cin >> L[i];
        cnt[L[i]]++;
    }
    long long sum_cnt[4001] = {0}; 
    for(int i = 1; i <= 2000; i++) {
        if(cnt[i] == 0) continue;
        for(int j = i; j <= 2000; j++) {
            if(cnt[j] == 0) continue;
            long long pairs = (i == j) ? 1LL * cnt[i] * (cnt[i] - 1) / 2                            : 1LL * cnt[i] * cnt[j];
            sum_cnt[i + j] += pairs;
        }
    }
    long long max_len = 0;
    int count_heights = 0;
    for(int s = 2; s <= 4000; s++) {
        if(sum_cnt[s] > max_len) {
            max_len = sum_cnt[s];
            count_heights = 1;
        } else if(sum_cnt[s] == max_len && max_len > 0) {
            count_heights++;
        }
    }
    cout << max_len << " " << count_heights << "\n";
}