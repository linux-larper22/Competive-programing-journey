#include <bits/stdc++.h>
using namespace std;

bool ok(int x){
    int prev = -1;
    while (x > 0){
        int d = x % 10;
        if (d == prev) return false;
        prev = d;
        x /= 10;
    }
    return true;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long N;
    if (!(cin >> N)) return 0;

    long long cnt = 0;
    for (int x = 1; x <= N; ++x){
        if (ok(x)) ++cnt;
    }

    cout << cnt << '\n';
}