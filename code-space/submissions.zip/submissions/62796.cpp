#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m;
    cin >> n >> m;
    vector<long long> a(n), b(m);
    for (auto &x : a) cin >> x;
    for (auto &x : b) cin >> x;
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());
    vector<long long> res;
    int i = 0, j = 0;
    while (i < n && j < m) 
    {
        if (a[i] == b[j]) {
            res.push_back(a[i]);
            i++; j++;
        } else if (a[i] < b[j]) i++;
        else j++;
    }
    if (res.empty()) 
    {
        cout << 0;
    } else {
        cout << res.size() << "\n";
        for (auto x : res) cout << x << " ";
    }
    return 0;
}