#include <bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long a, b, c, d;
    cin >> a >> b;
    cin >> c >> d;
    long long L = max(a, c);
    long long R = min(b, d);
    if (L > R) {
        cout << 0;
    } else {
        cout << (R - L + 1);
    }
}