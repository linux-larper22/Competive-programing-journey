#include <bits/stdc++.h>
using namespace std;
int F(long long x) 
{
    if (x == 0) return 0;
    return 1 + (x - 1) % 9;
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) 
    {
        long long x;
        cin >> x;
        cout << F(x);
        if (i + 1 < n) cout << ' ';
    }
}