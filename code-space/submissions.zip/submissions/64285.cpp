#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while(t--) {
        int n;
        cin >> n;
        vector<int> a(n);
        for(int i=0;i<n;i++) cin >> a[i];
        sort(a.begin(), a.end());

        int max_val = a[n-1];
        long long ans = 0;

        for(int i=0;i<n-2;i++){
            for(int j=i+1;j<n-1;j++){
                int target = max_val - a[i] - a[j];
                auto it = upper_bound(a.begin()+j+1, a.end(), target);
                ans += (a.end() - it);
            }
        }

        cout << ans << "\n";
    }
    return 0;
}