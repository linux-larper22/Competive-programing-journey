#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    ll k;
    cin >> n >> k;

    vector<ll> h(n);
    for (auto &x : h) cin >> x;

    sort(h.begin(), h.end());

    ll res = 0;
    int j = 0;

    for (int i = 0; i < n; i++) {
        while (j < n && h[j] - h[i] <= k) j++;
        res += (j - i - 1);
    }

    cout << res;
}