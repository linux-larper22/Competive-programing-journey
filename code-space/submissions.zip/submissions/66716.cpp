#include <bits/stdc++.h>
using namespace std;
long long gcd(long long a, long long b) {
    while (b) {
        a %= b;
        swap(a, b);
    }
    return a;
}

int main() {
    freopen("remain.inp", "r", stdin);
    freopen("remain.out", "w", stdout);

    int n;
    if (!(cin >> n)) return 0;
    vector<long long> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];

    if (n < 2) return 0;
    long long result = abs(a[1] - a[0]);
    for (int i = 2; i < n; ++i) {
        result = gcd(result, abs(a[i] - a[i-1]));
    }

    cout << result << endl;

    return 0;
}