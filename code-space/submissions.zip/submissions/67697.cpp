#include <bits/stdc++.h>
using namespace std;
bool isPal(const string &s) 
{
    int l = 0, r = s.size() - 1;
    while (l < r) {
        if (s[l] != s[r]) return false;
        l++; r--;
    }
    return true;
}
bool check(string s, int l, int r) 
{
    reverse(s.begin() + l, s.begin() + r + 1);
    return isPal(s);
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int T;
    cin >> T;
    while (T--) 
    {
        string s;
        cin >> s;
        int l = 0, r = s.size() - 1;
        while (l < r && s[l] == s[r]) 
        {
            l++; r--;
        }
        if (l >= r) 
        {
            cout << "YES\n";
            continue;
        }
        bool ok = false;
        for (int k = l; k <= r; k++) 
        {
            if (check(s, l, k)) {
                ok = true;
                break;
            }
        }
        if (!ok) {
            for (int k = r; k >= l; k--) 
            {
                if (check(s, k, r)) {
                    ok = true;
                    break;
                }
            }
        }

        cout << (ok ? "YES\n" : "NO\n");
    }
}