#include<bits/stdc++.h>
using namespace std;
int main(){
    long long a, b, c, d;
    cin>>a>>b;
    cin>>c>>d;
    long long u = max(a, c);
    long long v = min(b, d);
    //u <= x <= v;
    if(u > v) cout<<0;
    else cout<<v-u+1;
    return 0;
}