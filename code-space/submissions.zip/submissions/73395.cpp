#include <bits/stdc++.h>
using namespace std;

const int MAXN = 10000000;

bitset<MAXN + 1> prime;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int a, b;
    cin >> a >> b;
    prime.set();
    prime[0] = prime[1] = 0;
    for (int i = 2; 1LL * i * i <= MAXN; i++) {
        if (prime[i]) {
            for (int j = i * i; j <= MAXN; j += i)
                prime[j] = 0;
        }
    }
    vector<int> primes;
    for (int i = 2; i <= MAXN; i++) {
        if (prime[i]) primes.push_back(i);
    }
    int ans = 0;
    for (long long p : primes) {
        long long x = p * p * p;
        if (x > b) break;

        if (x >= a) ans++;
    }
    int sz = primes.size();
    for (int i = 0; i < sz; i++) {
        long long p = primes[i];
        for (int j = i + 1; j < sz; j++) 
        {
            long long q = primes[j];
            long long x = p * q;

            if (x > b) break;

            if (x >= a) ans++;
        }
    }
    cout << ans;
}