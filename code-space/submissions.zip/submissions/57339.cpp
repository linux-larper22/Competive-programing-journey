#include <bits/stdc++.h>
using namespace std;
using int64 = long long;
int64 mulmod(int64 a, int64 b, int64 mod) {
    __int128 t = (__int128)a * b;
    return (int64)(t % mod);
}
int64 powmod(int64 a, int64 e, int64 mod) 
{
    int64 res = 1;
    while (e) {
        if (e & 1) res = mulmod(res, a, mod);
        a = mulmod(a, a, mod);
        e >>= 1;
    }
    return res;
}
bool isPrime(int64 n) {
    if (n < 2) return false;
    for (int64 p : {2, 3, 5, 7, 11, 13, 17}) {
        if (n == p) return true;
        if (n % p == 0 && n != p) return false;
    }
    int64 d = n - 1, s = 0;
    while ((d & 1) == 0) {
        d >>= 1;
        s++;
    }
    for (int64 a : {2, 3, 5, 7, 11, 13, 17}) {
        if (a >= n) continue;
        int64 x = powmod(a, d, n);
        if (x == 1 || x == n - 1) continue;
        bool comp = true;
        for (int i = 1; i < s; i++) {
            x = mulmod(x, x, n);
            if (x == n - 1) {
                comp = false;
                break;
            }
        }
        if (comp) return false;
    }
    return true;
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) 
    {
        int64 n;
        cin >> n;
        int64 x = n + 1;
        while (!isPrime(x)) x++;
        cout << x << "\n";
    }
}