#include <bits/stdc++.h>
using namespace std;
long long gcd(long long a, long long b) {
    while (b) {
        a %= b;
        swap(a, b);
    }
    return a;
}

int main() 
{
    int n;
    if (!(cin >> n)) return 0;

    vector<long long> a(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    long long result = 0;
    for (int i = 0; i < n - 1; ++i) {
        long long diff = abs(a[i+1] - a[i]);
        if (diff != 0) {
            if (result == 0) result = diff;
            else result = gcd(result, diff);
        }
    }

    cout << result << endl;

    return 0;
}