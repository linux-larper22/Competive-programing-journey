include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    int C;
    cin >> C;
    int a[3][100005];

    for (int i = 1; i <= 2; i++)
        for (int j = 1; j <= C; j++)
            cin >> a[i][j];

    int ans = 0;

    for (int i = 1; i <= 2; i++)
        for (int j = 1; j <= C; j++)
            if (a[i][j] == 1)
                ans += 3;

    for (int j = 1; j <= C; j++) {

        if (a[1][j] && a[2][j]) ans -= 2;

        if (j < C && a[1][j] && a[2][j + 1]) ans -= 2;

        if (j < C && a[2][j] && a[1][j + 1]) ans -= 2;
    }

    cout << ans;

}