#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while (T--) 
    {
        int N;
        long long X;
        cin >> N >> X;
        vector<pair<long long, int>> v;
        v.reserve(N);
        for (int i = 1; i <= N; i++) 
        {
            long long A;
            cin >> A;
            long long turns = (A + X - 1) / X; // ceil(A/X)
            v.push_back({turns, i});
        }
        stable_sort(v.begin(), v.end());

        for (auto &p : v)
            cout << p.second << " ";
        cout << '\n';

}