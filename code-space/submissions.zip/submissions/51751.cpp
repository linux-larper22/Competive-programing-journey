#include <bits/stdc++.h>
using namespace std;
int main()
{
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int L, R;
    cin >> L >> R;
    int maxP = 2 * R + 1;
    vector<bool> isPrime(maxP + 1, true);
    isPrime[0] = isPrime[1] = false;
    for (int i = 2; i * i <= maxP; i++) 
    {
        if (isPrime[i]) {
            for (int j = i * i; j <= maxP; j += i)
                isPrime[j] = false;
        }
    }
    int cnt = 0;
    for (int a = L; a < R; a++) 
    {
        int b = a + 1;
        if (b > R) break;
        int val = 2 * a + 1;
        if (isPrime[val]) cnt++;
    }
    cout << cnt;
}