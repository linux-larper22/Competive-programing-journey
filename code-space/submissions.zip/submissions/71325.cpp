#include <bits/stdc++.h>
using namespace std;
int main()
{
    char c; cin >> c;
    string s; cin >> s;
    int cnt = 0;
    for(char x : s)
        if(x != c) cnt++;
    cout << cnt;
}