#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N, m;
    cin >> N >> m;
    vector<int> k(m);
    for (int &x : k) cin >> x;
    sort(k.begin(), k.end());
    int dem = 0;
    long long tong = 0;
    for (int x : k) 
    {
        if (tong + x > N) break;
        tong += x;
        dem++;
    }
    cout << dem;
}