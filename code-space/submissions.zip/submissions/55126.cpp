#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N;
    cin >> N;
    while (N--) {
        long long x;
        cin >> x;
        vector<long long> primes;
        for (long long p = 2; p * p <= x; ++p) 
        {
            if (x % p == 0) {
                primes.push_back(p);
                while (x % p == 0) x /= p;
            }
        }
        if (x > 1) primes.push_back(x);
        for (long long p : primes) cout << p << " ";
        cout << "\n";
    }
}