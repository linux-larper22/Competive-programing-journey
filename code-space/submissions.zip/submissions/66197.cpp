#include <bits/stdc++.h>
using namespace std;

string normalize(string s) {
    int i = 0;
    while (i < s.size() && s[i] == '0') i++;
    if (i == s.size()) return "0";
    return s.substr(i);
}

bool bigger(string a, string b) {
    a = normalize(a);
    b = normalize(b);

    if (a.size() != b.size()) return a.size() > b.size();
    return a > b;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    string s; cin >> s;
    string cur = "", ans = "0";

    for (char c : s) {
        if (isdigit(c)) {
            cur += c;
        } else {
            if (!cur.empty() && bigger(cur, ans)) ans = cur;
            cur = "";
        }
    }

    if (!cur.empty() && bigger(cur, ans)) ans = cur;

    cout << normalize(ans);
}