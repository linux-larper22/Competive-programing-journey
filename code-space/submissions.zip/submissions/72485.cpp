#include <bits/stdc++.h>
using namespace std;

struct Node {
    int val, pos;
};

Node seg[400005];
int a[100005];
int n;
long long k;

Node merge(Node a, Node b) {
    if (a.val > b.val) return a;
    return b;
}

void build(int id, int l, int r) {
    if (l == r) {
        seg[id] = {a[l], l};
        return;
    }
    int m = (l + r) / 2;
    build(id*2, l, m);
    build(id*2+1, m+1, r);
    seg[id] = merge(seg[id*2], seg[id*2+1]);
}

Node getMax(int id, int l, int r, int u, int v) {
    if (v < l || r < u) return {-1, -1};
    if (u <= l && r <= v) return seg[id];
    int m = (l + r) / 2;
    return merge(getMax(id*2,l,m,u,v),
                 getMax(id*2+1,m+1,r,u,v));
}

void update(int id, int l, int r, int pos, int val) {
    if (l == r) {
        seg[id] = {val, pos};
        return;
    }
    int m = (l + r) / 2;
    if (pos <= m) update(id*2, l, m, pos, val);
    else update(id*2+1, m+1, r, pos, val);

    seg[id] = merge(seg[id*2], seg[id*2+1]);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    cin >> n >> k;
    for (int i = 1; i <= n; i++) cin >> a[i];

    build(1, 1, n);

    for (int i = 1; i <= n && k > 0; i++) {
        int r = min(n, i + (int)k);

        Node best = getMax(1, 1, n, i, r);

        if (best.pos != i) {
            k -= (best.pos - i);

            int val = best.val;

            for (int j = best.pos; j > i; j--) {
                a[j] = a[j-1];
            }
            a[i] = val;

            build(1, 1, n);
        }
    }

    for (int i = 1; i <= n; i++) {
        cout << a[i] << " ";
    }
}