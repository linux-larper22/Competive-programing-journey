#include <bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n, k;
    cin >> n >> k;
    static int a[1000005];
    long long totalGreen = 0;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        if (a[i] == 1) totalGreen++;
    }
    int curOnes = 0;
    for (int i = 1; i <= k; i++) {
        if (a[i] == 1) curOnes++;
    }
    int minOnes = curOnes;
    for (int i = k + 1; i <= n; i++) {
        if (a[i - k] == 1) curOnes--;
        if (a[i] == 1) curOnes++;
        if (curOnes < minOnes) minOnes = curOnes;
    }
    long long ans = totalGreen + (k - 2LL * minOnes);
    cout << ans;
}