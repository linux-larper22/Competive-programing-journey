#include <bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    long long sum = 0;
    long long ans = 0;
    for (int i = 0; i < n; i++) 
    {
        long long h;
        cin >> h;
        ans += h * sum;
        sum += h;
    }
    cout << ans;
}