#include <bits/stdc++.h>
using namespace std;

int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(0);

    int n; cin >> n;
    vector<long long> cnt(200, 0);

    for (int i = 0; i < n; i++) 
    {
        long long x; cin >> x;
        int r = ((x % 200) + 200) % 200;
        cnt[r]++;
    }

    long long ans = 0;
    for (int i = 0; i < 200; i++) {
        ans += cnt[i] * (cnt[i] - 1) / 2;
    }

    cout << ans;
}