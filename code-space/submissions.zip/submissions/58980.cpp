#include <bits/stdc++.h>
using namespace std;
int main() 
{
    int n;
    cin >> n;
    int dem[10] = {0};
    for (int i = 0; i < n; i++) 
    {
        int x;
        cin >> x;
        dem[x]++;
    }
    for (int i = 0; i < 10; i++) 
    {
        cout << dem[i] << '\n';
    }
}