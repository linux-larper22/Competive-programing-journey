#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    long long n;
    cin >> n;

    vector<long long> a(n);

    long long sum = 0;

    for(int i=0;i<n;i++)
    {
        cin >> a[i];
        sum += a[i];
    }

    sort(a.begin(),a.end());

    long long low = sum / n;
    long long high = low + 1;

    long long k = sum % n;

    long long move = 0;

    for(int i=0;i<n-k;i++)
        if(a[i] > low)
            move += a[i] - low;

    for(int i=n-k;i<n;i++)
        if(a[i] > high)
            move += a[i] - high;

    cout << high - low << "\n";
    cout << move << "\n";
}