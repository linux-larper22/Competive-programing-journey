#include <iostream>
using namespace std;
int main() {
    int n;
    cin >> n;
    int x, y;

    int currentPassengers = 0;

    int maxPassengers = 0;

    for (int i = 1; i <= n; i++) {
        cin >> x >> y;                
        currentPassengers = currentPassengers - y + x; 

        if (currentPassengers > maxPassengers) {
            maxPassengers = currentPassengers;
        }
    }
    cout << maxPassengers << endl;

    return 0;
}