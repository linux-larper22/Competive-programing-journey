#include <bits/stdc++.h>
using namespace std;
int main() 
{
    long long trai, phai;
    cin >> trai >> phai;
    long long demCap = 0;
    for (long long a = trai; a < phai; a++) 
    {
        for (long long b = a + 1; b <= phai; b++) 
        {
            if (gcd(a, b) > 1)
                demCap++;
        }
    }
    cout << demCap;
}