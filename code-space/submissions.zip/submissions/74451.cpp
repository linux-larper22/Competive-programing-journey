#include <bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n;
    cin >> n;
    long long c[3]={0};
    for(long long i=0;i<n;i++)
    {
        long long x;
        cin >> x;
        c[x%3]++;
    }
    long long ans =
        c[0]*(c[0]-1)/2 +
        c[1]*c[2];
    cout << ans;
}