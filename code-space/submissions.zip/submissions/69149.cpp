#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    long long m;
    cin >> n >> m;
    vector<pair<long long,int>> a(n);
    for (int i = 0; i < n; i++) 
    {
        cin >> a[i].first;
        a[i].second = i;
    }
    sort(a.begin(), a.end());
    long long cur = a[0].first;
    int i = 1;
    while (i < n) 
    {
        long long diff = a[i].first - cur;
        long long cost = diff * i;

        if (m >= cost) {
            m -= cost;
            cur = a[i].first;
            i++;
        } else {
            break;
        }
    }
    long long add = m / i;
    long long rem = m % i;
    cur += add;
    vector<long long> res(n);
    for (int j = 0; j < n; j++) 
    {
        if (j < i) {
            res[a[j].second] = cur;
        } else {
            res[a[j].second] = a[j].first;
        }
    }
    for (int j = 0; j < i; j++) 
    {
        if (rem > 0) {
            res[a[j].second]++;
            rem--;
        }
    }
    long long mn = *min_element(res.begin(), res.end());
    cout << mn << "\n";
    for (auto x : res) cout << x << " ";
    return 0;
}