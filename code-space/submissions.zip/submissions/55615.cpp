#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    long long k;
    cin >> n >> k;
    vector<long long> h(n);
    for (int i = 0; i < n; i++) cin >> h[i];
    sort(h.begin(), h.end());
    int i = 0, j = n / 2;
    int dem = 0;
    while (i < n / 2 && j < n) 
    {
        if (h[j] - h[i] >= k) 
        {
            dem++;
            i++;
            j++;
        } else 
        {
            j++;
        }
    }
    cout << dem;
}