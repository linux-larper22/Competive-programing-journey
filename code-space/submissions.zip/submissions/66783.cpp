#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll gcd(ll a, ll b) {
    while (b) {
        a %= b;
        swap(a, b);
    }
    return a;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    if (!(cin >> n)) return 0;

    vector<ll> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];

    ll res = 0;
    for (int i = 1; i < n; ++i) {
        ll diff = abs(a[i] - a);
        if (diff > 0) {
            if (res == 0) res = diff;
            else res = gcd(res, diff);
        }
    }

    cout << res;

    return 0;
}