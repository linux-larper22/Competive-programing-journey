#include <bits/stdc++.h>
using namespace std;
using ll = long long;

bool isPrime(int x)
{
    if (x < 2) return false;
    for (int i = 2; i * i <= x; i++)
        if (x % i == 0) return false;
    return true;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n, k; cin >> n >> k;
    vector<int> a(n+1), pref(n+1);

    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
        pref[i] = (pref[i-1] + a[i]) % k;
    }

    vector<ll> cnt(k, 0);
    cnt[0] = 1;

    ll res = 0;

    for (int i = 1; i <= n; i++) 
    {
        for (int p = 2; p < k; p++) 
        {
            if (!isPrime(p)) continue;
            int need = (pref[i] - p + k) % k;
            res += cnt[need];
        }
        cnt[pref[i]]++;
    }

    cout << res;
}