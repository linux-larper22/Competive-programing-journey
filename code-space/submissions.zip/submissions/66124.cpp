#include <bits/stdc++.h>
using namespace std;
using ll = long long;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n; cin >> n;
    ll sum = 0;
    ll min_odd = LLONG_MAX;
    for (int i = 0; i < n; i++) 
    {
        ll x; cin >> x;
        sum += x;
        if (x % 2) min_odd = min(min_odd, x);
    }

    if (sum % 2 == 0) cout << sum;
    else cout << sum - min_odd;
}