#include <bits/stdc++.h>
using namespace std;
int main() 
{
    string s;
    cin >> s;
    set<int> st;
    int n = s.size();
    for (int i = 0; i < n; ) 
    {
        if (isdigit(s[i])) 
        {
            int num = 0;
            while (i < n && isdigit(s[i])) 
            {
                num = num * 10 + (s[i] - '0');
                i++;
            }
            st.insert(num);
        } else i++;
    }
    cout << st.size();
    return 0;
}