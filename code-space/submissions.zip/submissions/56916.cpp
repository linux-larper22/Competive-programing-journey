#include <bits/stdc++.h>
using namespace std;
int main() 
{
    int n, m;
    cin >> n >> m;
    vector<long long> A(n), B(m);
    long long Sa = 0, Sb = 0;
    for (int i = 0; i < n; i++) 
    {
        cin >> A[i];
        Sa += A[i];
    }
    for (int j = 0; j < m; j++) {
        cin >> B[j];
        Sb += B[j];
    }
    long long D = Sa - Sb;
    long long ket_qua = llabs(D);
    vector<long long> diff;
    for (int i = 0; i < n; i++) 
    {
        for (int j = 0; j < m; j++) 
        {
            diff.push_back(A[i] - B[j]);
        }
    }
    sort(diff.begin(), diff.end());
    for (long long x : diff) 
    {
        long long val = llabs(D - 2 * x);
        if (val < ket_qua) ket_qua = val;
    }
    int l = 0, r = diff.size() - 1;
    while (l < r) 
    {
        long long sum = diff[l] + diff[r];
        long long val = llabs(D - 2 * sum);
        if (val < ket_qua) ket_qua = val;

        if (2 * sum > D) r--;
        else l++;
    }
    cout << ket_qua;
}