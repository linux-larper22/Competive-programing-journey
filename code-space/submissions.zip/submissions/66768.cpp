#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;
int n, k;
int h;

int main() {
    // Tối ưu tốc độ nhập xuất
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    if (!(cin >> n >> k)) return 0;
    for (int i = 1; i <= n; i++) {
        cin >> h[i];
    }
    sort(h + 1, h + n + 1);

    long long ans = 0;
    int i = 1;
    for (int j = 1; j <= n; j++) {
        int x = h[j] - k;
        while (i < j && h[i] < x) {
            i++;
        }
        if (i < j) {
            ans += (long long)(j - i);
        }
    }
    cout << ans << endl;

    return 0;
}