#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while(t--) {
        int n;
        cin >> n;
        vector<int> a(n);
        for(int i=0;i<n;i++) cin >> a[i];
        sort(a.begin(), a.end());

        long long ans = 0;
        for(int i=0;i<n-2;i++){
            for(int j=i+1;j<n-1;j++){
                long long required = a[n-1]; 
                long long sum2 = a[i] + a[j];
                if(sum2 > required) continue; 
                int k = upper_bound(a.begin()+j+1,a.end(), required - sum2) - a.begin();
                ans += n - k;
            }
        }
        cout << ans << '\n';
    }
    return 0;
}