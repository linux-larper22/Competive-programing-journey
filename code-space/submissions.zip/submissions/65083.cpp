#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m, q;
    cin >> n >> m >> q;
    vector<long long> a(n), b(m);
    for (auto &x : a) cin >> x;
    for (auto &x : b) cin >> x;
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());
    while (q--) 
    {
        long long x;
        cin >> x;
        int cntA = upper_bound(a.begin(), a.end(), x) - a.begin();
        int cntB = b.end() - lower_bound(b.begin(), b.end(), x);

        cout << 1LL * cntA * cntB << "\n";
    }
}