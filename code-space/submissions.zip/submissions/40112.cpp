#include <bits/stdc++.h>
using namespace std;

const int N = 1e6 + 6;
int n, k, a[N];
long long sum[N], maxL[N], maxR[N];

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> n >> k;

    for (int i = 1; i <= n; i++) 
        cin >> a[i];

    // Tính prefix sum
    for (int i = 1; i <= n; i++) 
        sum[i] = a[i] + sum[i-1];

    // Tính maxL[i]: tổng lớn nhất của k phần tử liên tiếp kết thúc tại i
    maxL[k] = sum[k]; 
    for (int i = k + 1; i <= n; i++) {
        long long e = sum[i] - sum[i-k];
        maxL[i] = max(e, maxL[i-1]);
    }

    // Tính maxR[i]: tổng lớn nhất của k phần tử liên tiếp bắt đầu từ i
    maxR[n-k+1] = sum[n] - sum[n-k];
    for (int i = n - k; i >= 1; i--) {
        long long e = sum[i+k-1] - sum[i-1];
        maxR[i] = max(e, maxR[i+1]);
    }

    // Sau bước này, maxL và maxR đã được tính đầy đủ
}