#include <bits/stdc++.h>
using namespace std;

const int MAXN = 200000 * 2 + 5;

bool prime[MAXN];
void sieve() 
{
    fill(prime, prime + MAXN, true);
    prime[0] = prime[1] = false;
    for (int i = 2; i * i < MAXN; i++) 
    {
        if (prime[i]) {
            for (int j = i * i; j < MAXN; j += i)
                prime[j] = false;
        }
    }
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    sieve();
    int L, R;
    cin >> L >> R;
    int ans = 0;
    for (int a = L; a < R; a++) 
    {
        int val = 2 * a + 1;

        if (prime[val])
            ans++;
    }

    cout << ans;
}