#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    long long k;
    cin >> n >> k;

    vector<int> a(n);
    for (int &x : a) cin >> x;

    for (int i = 0; i < n && k > 0; i++) {
        int pos = i;
        for (int j = i + 1; j < n && j <= i + k; j++) {
            if (a[j] > a[pos]) pos = j;
        }

        for (int j = pos; j > i; j--) {
            swap(a[j], a[j - 1]);
        }

        k -= (pos - i);
    }

    for (int x : a) cout << x << " ";
}