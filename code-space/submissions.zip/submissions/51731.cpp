#include <bits/stdc++.h>
using namespace std;
int main() 
{
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    long long a, b;
    cin >> a >> b;
    int cnt = 0;
    if ((a + b) % 3 == 0) cnt++;
    if ((a - b) % 3 == 0) cnt++;
    if ((a * b) % 3 == 0) cnt++;
    if (a % b == 0 && (a / b) % 3 == 0) cnt++;
    cout << cnt;
}