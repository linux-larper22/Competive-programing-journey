#include <bits/stdc++.h>
using namespace std;

bool bigger(string a, string b) {
    if (a.size() != b.size()) return a.size() > b.size();
    return a > b;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    string s; cin >> s;
    string cur = "", ans = "0";

    for (char c : s) {
        if (isdigit(c)) {
            cur += c;
        } else {
            if (!cur.empty() && bigger(cur, ans)) ans = cur;
            cur = "";
        }
    }
    if (!cur.empty() && bigger(cur, ans)) ans = cur;

    cout << ans;
}