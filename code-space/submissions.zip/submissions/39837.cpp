#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    if (!(cin >> n >> k)) return 0;
    vector<long long> a(n+1);
    for (int i = 1; i <= n; ++i) cin >> a[i];

    int M = n - k + 1; 
    vector<long long> W(max(1, M+1));
    long long cur = 0;
    for (int i = 1; i <= k; ++i) cur += a[i];
    if (M >= 1) W[1] = cur;
    for (int i = 2; i <= M; ++i) {
        cur += a[i + k - 1];
        cur -= a[i - 1];
        W[i] = cur;
    }
    vector<long long> L(max(1, M+1));
    if (M >= 1) {
        L[1] = W[1];
        for (int i = 2; i <= M; ++i) L[i] = max(L[i-1], W[i]);
    }
    vector<long long> R(max(1, M+2));
    if (M >= 1) {
        R[M] = W[M];
        for (int i = M-1; i >= 1; --i) R[i] = max(R[i+1], W[i]);
    }

    long long ans = 0;
    for (int m = k + 1; m <= M - k; ++m) {
        long long leftMax = L[m - k];  
        long long rightMax = R[m + k]; 
        long long total = leftMax + W[m] + rightMax;
        if (total > ans) ans = total;
    }

    cout << ans << '\n';
}