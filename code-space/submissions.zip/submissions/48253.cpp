#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<int> x(n + 1);
    for (int i = 1; i <= n; i++) {
        int y;
        cin >> x[i] >> y;
        vector<int> uoc;
        for (int d = 1; d * d <= x[i]; d++) {
            if (x[i] % d == 0) {
                uoc.push_back(d);
                if (d * d != x[i]) uoc.push_back(x[i] / d);
            }
        }
        int dem = 0;
        for (int d : uoc) {
            bool ok = true;
            for (int j = i - y; j <= i - 1; j++) {
                if (x[j] % d == 0) {
                    ok = false;
                    break;
                }
            }
            if (ok) dem++;
        }
        cout << dem << "\n";
    }
}