#include <bits/stdc++.h>
using namespace std;
int main() 
{
    long long n;
    cin >> n;
    long long chan = 0, le = 0;
    for (int i = 0; i < n; i++) 
    {
        int x;
        cin >> x;
        if (x % 2 == 0) chan++;
        else le++;
    }
    long long cap_chan = chan * (chan - 1) / 2 + le * (le - 1) / 2;
    long long cap_le = chan * le;
    cout << cap_chan << '\n' << cap_le;

}