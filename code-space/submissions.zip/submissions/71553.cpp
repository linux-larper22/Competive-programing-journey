#include <bits/stdc++.h>
using namespace std;

int main() {
    freopen("Xanhdep1.inp", "r", stdin);
    freopen("Xanhdep1.out", "w", stdout);

    char c;
    string s;

    cin >> c >> s;

    int ans = 0;

    for (char x : s)
        if (x != c) ans++;

    cout << ans;

    return 0;
}