#include <bits/stdc++.h>
using namespace std;
int main() 
{
    long long k;
    cin >> k;
    long long dem = 0;
    for (long long i = 1; ; i++) 
    {
        if (i % 3 == 0 || i % 5 == 0 || i % 7 == 0) 
        {
            dem++;
            if (dem == k) 
            {
                cout << i;
                break;
            }
        }
    }
}