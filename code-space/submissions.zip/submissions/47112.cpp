#include <bits/stdc++.h>
using namespace std;
int trang_thai[1000005];
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, so_truy_van;
    cin >> n >> so_truy_van;
    string xau;
    cin >> xau;
    trang_thai[0] = 0;
    for (int i = 0; i < n; i++) {
        int mask = trang_thai[i];
        int bit = 1 << (xau[i] - 'a')
        if (mask & bit) mask -= bit;   // le -> chan
        else mask += bit;              // chan -> le

        trang_thai[i + 1] = mask;
    }
    while (so_truy_van--) {
        int trai, phai;
        cin >> trai >> phai;
        trai--;
        phai--;
        int mask_trai = trang_thai[trai];
        int mask_phai = trang_thai[phai + 1];
        int so_ky_tu_le = 0;
        for (int c = 0; c < 26; c++) {
            int bit = 1 << c;
            int le_trai = (mask_trai & bit) != 0;
            int le_phai = (mask_phai & bit) != 0;
            if (le_trai != le_phai) so_ky_tu_le++;
        }
        int dap_an = 0;
        if (so_ky_tu_le > 1)
            dap_an = (so_ky_tu_le - 1) / 2;
        cout << dap_an << '\n';
    }
}