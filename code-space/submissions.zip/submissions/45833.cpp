#include <bits/stdc++.h>
using namespace std;
long long b[100000 + 5];
int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    long long X, Y, K;
    cin >> n >> X >> Y >> K;
    int m = 0;
    for (int i = 1; i <= n; i++) 
    {
        long long x;
        cin >> x;
        if (x >= X && x <= Y) 
        {
            b[m++] = x;
        }
    }
    sort(b, b + m);
    long long sum = 0;
    int cnt = 0;
    for (int i = 0; i < m; i++) 
    {
        if (sum + b[i] <= K) 
        {
            sum += b[i];
            cnt++;
        } else {
            break;
        }
    }
    cout << cnt;
}