#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m, k;
    cin >> n >> m >> k;
    vector<int> a(n);
    for (int &x : a) cin >> x;
    vector<long long> cnt(k, 0);
    long long cur = 0, ans = 0;
    for (int i = 0; i < n; i++) 
    {
        int r = a[i] % k;
        int need = (k - r) % k;
        cur += cnt[need];
        cnt[r]++;
        if (i >= m) 
        {
            int old = a[i - m] % k;
            cnt[old]--;
            int need2 = (k - old) % k;
            cur -= cnt[need2];
        }

        if (i >= m - 1)
            ans = max(ans, cur);
    }
    cout << ans;
}