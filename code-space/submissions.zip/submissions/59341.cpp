#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    cin >> n;

    int d[10] = {0};
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        d[x]++;
    }

    int ans = 0;
    for (int i = 1; i <= 9; i++)
        ans += d[i] / 2;

    cout << ans;
    return 0;
}