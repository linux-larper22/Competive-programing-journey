#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N;
    cin >> N;
    unordered_map<int,int> cnt;
    for (int i = 0; i < N; i++) 
    {
        int x; cin >> x;
        cnt[x]++;
    }
    long long keep = 0;
    for (auto &p : cnt) 
    {
        int x = p.first;
        int c = p.second;
        if (c >= x) keep += x;
    }
    cout << N - keep;
}