#include <bits/stdc++.h>
using namespace std;
int k;
long long n, dem = 0;
vector<int> a;
bool used[10];
string ans;
bool done = false;
void dfs(string cur) {
    if (done) return;
    if (!cur.empty()) 
    {
        dem++;
        if (dem == n) 
        {
            ans = cur;
            done = true;
            return;
        }
    }
    if ((int)cur.size() == k) return;
    for (int i = 0; i < k; i++) 
    {
        if (!used[i]) {
            used[i] = true;
            dfs(cur + char('0' + a[i]));
            used[i] = false;
            if (done) return;
        }
    }
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> k >> n;
    a.resize(k);
    for (int i = 0; i < k; i++) cin >> a[i];
    sort(a.begin(), a.end());
    memset(used, false, sizeof(used));
    dfs("");
    cout << ans;
}