#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    long long n, k;
    cin >> n;

    vector<long long> a(n);
    for (auto &x : a) cin >> x;

    cin >> k;

    long long cur = 0, ans = 0;

    for (int i = 0; i < n; i++) {
        if (a[i] == k) {
            ans += cur * (cur + 1) / 2;
            cur = 0;
        } else {
            cur++;
        }
    }

    ans += cur * (cur + 1) / 2;

    cout << ans;
}