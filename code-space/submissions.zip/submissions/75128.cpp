#include <bits/stdc++.h>
using namespace std;
const long long MOD = 1e9 + 7;
int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    if (!(cin >> n)) return 0;
    long long dp[3] = {1, 0, 0}; 
    for (int i = 0; i < n; ++i) 
    {
        int a;
        cin >> a;
        int r = a % 3;
        long long c0 = dp[0];
        long long c1 = dp[1];
        long long c2 = dp[2];
        dp[0] = (c0 + c[(3 - r) % 3]) % MOD;
        dp[1] = (c1 + c[(4 - r) % 3]) % MOD;
        dp[2] = (c2 + c[(5 - r) % 3]) % MOD;
    }
    long long ans = (dp[0] - 1 + MOD) % MOD;
    cout << ans << "\n";
}