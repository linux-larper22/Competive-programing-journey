#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    long long W;
    cin >> n >> W;
    vector<long long> a(n), b(n);
    for (int i = 0; i < n; i++) cin >> a[i];
    for (int i = 0; i < n; i++) cin >> b[i];
    long long sumW = 0, sumV = 0;
    long long best = 0;
    int L = 0, bestL = -1, bestR = -1;
    for (int R = 0; R < n; R++) 
    {
        sumW += a[R];
        sumV += b[R];
        while (sumW > W) {
            sumW -= a[L];
            sumV -= b[L];
            L++;
        }
        if (sumV > best) 
        {
            best = sumV;
            bestL = L;
            bestR = R;
        }
    }
    if (best == 0) 
    {
        cout << 0;
    } else {
        cout << best << "\n" << bestL + 1 << " " << bestR + 1;
    }
}