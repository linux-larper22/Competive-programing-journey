#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<long long> a(n);
    for (auto &x : a) cin >> x;
    long long res = 0;
    for (int pos = 0; pos < 10; pos++) 
    {
        long long cnt[10] = {0};
        for (int i = 0; i < n; i++) 
        {
            if (a[i] > 0) 
            { 
                int digit = a[i] % 10;
                cnt[digit]++;
                a[i] /= 10;
            }
        }
        for (int d = 0; d < 10; d++) 
        {
            long long k = cnt[d];
            res += k * (k - 1) / 2;
        }
    }
    cout << res;
}