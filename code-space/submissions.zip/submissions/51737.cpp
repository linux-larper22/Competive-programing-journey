#include <bits/stdc++.h>
using namespace std;
int main() 
{
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++) cin >> a[i];
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            for (int k = 0; k < n; k++)
                if (i != j && j != k && i != k)
                    if (a[i] + a[j] == a[k]) {
                        cout << "Yes";
                        return 0;
                    }
    cout << "No";
}