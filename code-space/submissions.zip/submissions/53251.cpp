#include <bits/stdc++.h>
using namespace std;
vector<int> so;
long long dem = 0, n;
string ketqua;
bool xong = false;
void dfs(string cur) 
{
    if (xong) return;
    if (!cur.empty()) 
    {
        dem++;
        if (dem == n) 
        {
            ketqua = cur;
            xong = true;
            return;
        }
    }
    for (int d : so) {
        dfs(cur + char('0' + d));
        if (xong) return;
    }
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int k;
    cin >> k >> n;
    so.resize(k);
    for (int &x : so) cin >> x;
    sort(so.begin(), so.end());
    dfs("");
    cout << ketqua;
}