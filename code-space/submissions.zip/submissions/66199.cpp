#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n; cin >> n;
    vector<long long> a(n);
    for (auto &x : a) cin >> x;

    int cur = 1, res = 1;

    for (int i = 1; i < n; i++) {
        if (a[i] == a[i-1]) cur++;
        else cur = 1;
        res = max(res, cur);
    }

    cout << res;
}