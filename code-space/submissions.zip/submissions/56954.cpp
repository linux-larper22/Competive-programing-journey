#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m;
    cin >> n >> m;
    vector<long long> A(n), B(m);
    long long Sa = 0, Sb = 0;
    for (int i = 0; i < n; i++) 
    {
        cin >> A[i];
        Sa += A[i];
    }
    for (int j = 0; j < m; j++) 
    {
        cin >> B[j];
        Sb += B[j];
    }
    long long D = Sa - Sb;
    long long ans = llabs(D);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            ans = min(ans, llabs(D - 2 * (A[i] - B[j])));
    if (n >= 2 && m >= 2) {
        vector<long long> sumB;
        sumB.reserve((long long)m * (m - 1) / 2);
        for (int i = 0; i < m; i++)
            for (int j = i + 1; j < m; j++)
                sumB.push_back(B[i] + B[j]);
        sort(sumB.begin(), sumB.end());
        sort(A.begin(), A.end());
        const int LIM = 45; 
        for (int i = 0; i < n; i++) 
        {
            for (int k = i + 1; k < n && k <= i + LIM; k++) 
            {
                long long sumA = A[i] + A[k];
                long long target = sumA - D / 2;
                int pos = lower_bound(sumB.begin(), sumB.end(), target) - sumB.begin();
                if (pos < (int)sumB.size()) 
                {
                    long long cur = llabs(D - 2 * (sumA - sumB[pos]));
                    ans = min(ans, cur);
                }
                if (pos > 0) 
                {
                    long long cur = llabs(D - 2 * (sumA - sumB[pos - 1]));
                    ans = min(ans, cur);
                }
            }
        }
    }
    cout << ans;
}