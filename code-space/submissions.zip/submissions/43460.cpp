#include <bits/stdc++.h>
using namespace std;

int n, k;
pair<int, int> a[100001];

// Hàm so sánh: sắp xếp giảm dần theo first, nếu bằng thì tăng dần theo second
bool comp(pair<int,int> x, pair<int,int> y) {
    if (x.first > y.first) return true;
    if (x.first == y.first) return x.second < y.second;
    return false;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n >> k;
    fo