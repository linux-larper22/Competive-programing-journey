#include <bits/stdc++.h>
using namespace std;
bool prime(long long n)
{
    if(n < 2) return false;
    for(long long i = 2; i * i <= n; i++)
        if(n % i == 0) return false;
    return true;
}
int main()
{
    ios::sync_with_stdio (false);
    cin.tie(nullptr);
    long long n;
    cin >> n;
    long long sum = 0;
    while(n)
    {
        long long d = n % 10;
        sum += d * d;
        n /= 10;
    }
    cout << (prime(sum) ? 1 : -1) << '\n';
    cout << sum;
}