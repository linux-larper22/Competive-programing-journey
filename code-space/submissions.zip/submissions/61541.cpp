#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    string s;
    cin >> s;
    int n;
    cin >> n;
    vector<int> pos[26];
    for(int i=0;i<s.size();i++)
        pos[s[i]-'a'].push_back(i);
    while(n--)
    {
        string x;
        cin >> x;
        int cur = -1;
        bool ok = true;
        for(char c : x)
        {
            auto &v = pos[c-'a'];
            auto it = upper_bound(v.begin(), v.end(), cur);
            if(it == v.end())
            {
                ok = false;
                break;
            }
            cur = *it;
        }
        cout << ok << "\n";
    }
}