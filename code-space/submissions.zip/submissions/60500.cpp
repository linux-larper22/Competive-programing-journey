#include <bits/stdc++.h>
using namespace std;

long long solve(long long n){
    long long sum = 0;

    for(long long i=2;i*i<=n;i++){
        if(n%i==0){
            sum += 1LL*i*i;
            while(n%i==0) n/=i;
        }
    }

    if(n>1) sum += 1LL*n*n;

    return sum;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int T;
    cin>>T;

    while(T--){
        long long n;
        cin>>n;
        cout<<solve(n)<<"\n";
    }
}