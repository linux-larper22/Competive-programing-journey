#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int N;
    if (!(cin >> N)) return 0;
    vector<int> A(N);
    int maxA = 0;
    for (int i = 0; i < N; ++i) {
        cin >> A[i];
        maxA = max(maxA, A[i]);
    }
    unordered_map<int,int> freq;
    int best_duplicate = 0;
    for (int x : A) {
        ++freq[x];
        if (freq[x] >= 2) best_duplicate = max(best_duplicate, x);
    }
    if (maxA <= 1000000) {
        vector<int> cnt(maxA + 1, 0);
        for (int x : A) ++cnt[x];
        for (int g = maxA; g >= 1; --g) {
            int sum = 0;
            for (int mult = g; mult <= maxA; mult += g) {
                sum += cnt[mult];
                if (sum >= 2) break;
            }
            if (sum >= 2) {
                cout << g << '\n';
                return 0;
            }
        }
        cout << 1 << '\n'; 
        return 0;
    }
    if (best_duplicate > 0) {
        cout << best_duplicate << '\n';
        return 0;
    }

    int ans = 1;
    for (int i = 0; i < N; ++i) {
        for (int j = i + 1; j < N; ++j) {
            int g = std::gcd(A[i], A[j]);
            if (g > ans) ans = g;
            if (ans == maxA) { cout << ans << '\n'; return 0; }
        }
    }
    cout << ans << '\n';
}