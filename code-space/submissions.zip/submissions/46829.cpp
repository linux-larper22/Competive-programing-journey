#include <bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int soLuongA, soLuongB, doDaiDoan;
    cin >> soLuongA >> soLuongB >> doDaiDoan;
    long long* tongA = new long long[soLuongA - doDaiDoan + 1];
    long long tongHienTai = 0;
    for (int i = 0; i < soLuongA; i++) {
        long long giaTri;
        cin >> giaTri;
        tongHienTai += giaTri;
        if (i >= doDaiDoan)
            tongHienTai -= tongA[i - doDaiDoan]; 
        if (i >= doDaiDoan - 1)
            tongA[i - doDaiDoan + 1] = tongHienTai;
        else
            tongA[i] = giaTri; 
    }
    int soDoanA = soLuongA - doDaiDoan + 1;
    long long* tongB = new long long[soLuongB - doDaiDoan + 1];
    tongHienTai = 0;
    for (int i = 0; i < soLuongB; i++) {
        long long giaTri;
        cin >> giaTri;
        tongHienTai += giaTri;
        if (i >= doDaiDoan)
            tongHienTai -= tongB[i - doDaiDoan];
        if (i >= doDaiDoan - 1)
            tongB[i - doDaiDoan + 1] = tongHienTai;
        else
            tongB[i] = giaTri;
    }
    int soDoanB = soLuongB - doDaiDoan + 1;
    sort(tongB, tongB + soDoanB);
    long long ketQua = LLONG_MAX;
    for (int i = 0; i < soDoanA; i++) {
       long long giaTriA = tongA[i];
        int viTri = lower_bound(tongB, tongB + soDoanB, giaTriA) - tongB;
        if (viTri < soDoanB)
            ketQua = min(ketQua, llabs(giaTriA - tongB[viTri]));
        if (viTri > 0)
            ketQua = min(ketQua, llabs(giaTriA - tongB[viTri - 1]));
    }
    cout << ketQua;
}