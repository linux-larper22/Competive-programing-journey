#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    unordered_set<int> s;
    for (int i = 0; i < n; i++)
    {
        int a;
        cin >> a;
        s.insert(a);
    }
    int k;
    cin >> k;
    while (k--) 
    {
        int x;
        cin >> x;
        cout << (s.count(x) ? 1 : 0) << '\n';
    }
}