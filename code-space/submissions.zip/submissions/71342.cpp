#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const ll INF = (ll)4e18;

struct Line {
    ll m, b;
    ll get(ll x){
        return m*x + b;
    }
};

deque<Line> hull;

bool bad(Line l1, Line l2, Line l3){
    return (l2.b - l1.b) * (l1.m - l3.m)
        >= (l3.b - l1.b) * (l1.m - l2.m);
}

void add(Line L){
    while(hull.size() >= 2 &&
          bad(hull[hull.size()-2], hull.back(), L))
        hull.pop_back();
    hull.push_back(L);
}

ll query(ll x){
    while(hull.size() >= 2 &&
          hull[0].get(x) >= hull[1].get(x))
        hull.pop_front();
    return hull[0].get(x);
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;

    vector<ll>a(n+1), pref(n+1,0);
    for(int i=1;i<=n;i++){
        cin >> a[i];
        pref[i] = pref[i-1] + a[i];
    }

    vector<ll> dp_prev(n+1, INF), dp_cur(n+1, INF);
    dp_prev[0] = 0;

    for(int kk=1; kk<=k; kk++){
        hull.clear();

        add({0, dp_prev[0]});

        for(int i=1;i<=n;i++){
            ll x = pref[i];

            ll best = query(x);

            dp_cur[i] = best + kk * x;

            add({-pref[i], dp_prev[i]});
        }

        dp_prev = dp_cur;
    }

    cout << dp_prev[n];
}