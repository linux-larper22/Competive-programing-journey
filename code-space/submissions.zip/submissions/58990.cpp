#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cin >> n;

    long long dem[3] = {0};
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        dem[x % 3]++;
    }

    long long kq = 0;
    kq += dem[0] * (dem[0] - 1) / 2;
    kq += dem[1] * dem[2];

    cout << kq;
    return 0;
}