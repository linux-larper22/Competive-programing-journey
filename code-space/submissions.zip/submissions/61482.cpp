#include <bits/stdc++.h>
using namespace std;
const int MAX = 2000005;
bool prime[MAX];
void sieve()
{
    for(int i=0;i<MAX;i++) prime[i]=true;
    prime[0]=prime[1]=false;
    for(int i=2;i*i<MAX;i++)
        if(prime[i])
            for(int j=i*i;j<MAX;j+=i)
                prime[j]=false;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    sieve();
    int n;
    cin>>n;
    vector<int>a(n);
    for(int i=0;i<n;i++)
        cin>>a[i];
    long long ans=0;
    for(int i=0;i<n;i++)
        for(int j=i+1;j<n;j++)
        {
            long long sum = (long long)a[i] + a[j];
            if(sum >= 2 && sum < MAX && prime[sum])
                ans++;
        }
    cout<<ans;
}