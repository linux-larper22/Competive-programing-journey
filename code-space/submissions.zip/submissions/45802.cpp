#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    cin >> n;
    string s;
    cin >> s;
    int last[256];
    for (int i = 0; i < 256; i++)
        last[i] = -1;
    for (int i = 0; i < n; i++) {
        if (last[(unsigned char)s[i]] == -1)
            cout << -1;
        else
            cout << last[(unsigned char)s[i]];

        if (i < n - 1) cout << " ";
        last[(unsigned char)s[i]] = i;
    }
}