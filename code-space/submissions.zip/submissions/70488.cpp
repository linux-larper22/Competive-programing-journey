#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    vector<int> x(m);

    for (int &v : x) cin >> v;

    int ans = n - x[m - 1];

    for (int i = 0; i < m - 1; i++) {
        ans = max(ans, x[i + 1] - x[i] - 1);
    }

    cout << ans;
}