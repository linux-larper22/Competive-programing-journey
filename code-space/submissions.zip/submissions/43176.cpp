#include <iostream>
using namespace std;

int main() {
    int N;
    cin >> N; 

    int Swifts[100000];       
    int Semaphores[100000];   

    for(int i = 0; i < N; i++) {
        cin >> Swifts[i];
    }
    for(int i = 0; i < N; i++) {
        cin >> Semaphores[i];
    }

    int sumSwifts = 0;
    int sumSemaphores = 0;
    int K = 0; 

 
    for(int i = 0; i < N; i++) {
        sumSwifts += Swifts[i];
        sumSemaphores += Semaphores[i];

        if(sumSwifts == sumSemaphores) {
            K = i + 1; 
        }
    }

    cout << K << endl; 
}