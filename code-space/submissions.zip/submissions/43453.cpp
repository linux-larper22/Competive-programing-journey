#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    cin >> n;

    int a[100005];
    int i;
    int max_val = 0;

    for (i = 1; i <= n; i++) {
        cin >> a[i];
        if (a[i] > max_val) max_val = a[i];
    }

    long long left = 1, right = max_val;
    long long ans = 0;

    while (left <= right) {
        long long mid = (left + right) / 2;
        long long cnt = 0;

        for (i = 1; i <= n; i++)
            if (a[i] >= mid) cnt++;

        long long total = cnt * mid;

        if (total >= ans) { 
            ans = total;
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }

    cout << ans << "\n";
}