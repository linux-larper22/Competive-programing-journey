#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int x, n;
    cin >> x >> n;

    set<int> pos;
    multiset<int> seg;

    pos.insert(0);
    pos.insert(x);

    seg.insert(x);

    string ans;

    for (int i = 0; i < n; i++) {
        int p;
        cin >> p;

        auto it = pos.upper_bound(p);

        int r = *it;
        int l = *prev(it);

        pos.insert(p);

        auto eraseIt = seg.find(r - l);
        seg.erase(eraseIt);

        seg.insert(p - l);
        seg.insert(r - p);

        ans += to_string(*seg.rbegin()) + ' ';
    }

    cout << ans;

    return 0;
}