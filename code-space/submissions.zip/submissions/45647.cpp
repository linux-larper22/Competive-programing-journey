#include <bits/stdc++.h>
using namespace std;

int main() {
    long long x1, y1, x2, y2, x3, y3;
    cin >> x1 >> y1;
    cin >> x2 >> y2;
    cin >> x3 >> y3;

    // Tìm giao đoạn chung
    long long left = max({x1, x2, x3}); 
    long long right = min({y1, y2, y3}); 

    if (left > right) 
        cout << 0;   
    else 
        cout << right - left + 1; 
}