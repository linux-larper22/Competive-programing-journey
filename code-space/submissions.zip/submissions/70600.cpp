#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const ll INF = (ll)4e18;

struct Line {
    ll m, b;
    ll get(ll x) {
        return m * x + b;
    }
};

struct Node {
    Line line;
    Node *l = nullptr, *r = nullptr;
    Node(Line _line) : line(_line) {}
};

ll L = 1, R = 500000;

void add_line(Line nw, Node* &node, ll l = L, ll r = R) {
    if (!node) {
        node = new Node(nw);
        return;
    }

    ll mid = (l + r) >> 1;

    bool left = nw.get(l) < node->line.get(l);
    bool midv = nw.get(mid) < node->line.get(mid);

    if (midv) swap(node->line, nw);

    if (l == r) return;

    if (left != midv)
        add_line(nw, node->l, l, mid);
    else
        add_line(nw, node->r, mid + 1, r);
}

ll query(Node* node, ll x, ll l = L, ll r = R) {
    if (!node) return INF;

    ll res = node->line.get(x);
    if (l == r) return res;

    ll mid = (l + r) >> 1;
    if (x <= mid)
        return min(res, query(node->l, x, l, mid));
    else
        return min(res, query(node->r, x, mid + 1, r));
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;

    vector<ll> a(n + 1), pre(n + 1, 0);
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        pre[i] = pre[i - 1] + a[i];
    }

    vector<ll> dp_prev(n + 1), dp_cur(n + 1);

    for (int i = 1; i <= n; i++)
        dp_prev[i] = INF;

    dp_prev[0] = 0;

    for (int j = 1; j <= k; j++) {
        Node* root = nullptr;

        dp_cur[0] = 0;

        add_line({-pre[0], dp_prev[0]}, root);

        for (int i = 1; i <= n; i++) {
            dp_cur[i] = pre[i] * j + query(root, j);
            add_line({-pre[i], dp_prev[i]}, root);
        }

        dp_prev = dp_cur;
    }

    cout << dp_prev[n];
}