#include <bits/stdc++.h>
using namespace std;
int main() 
{
    int n; cin >> n;
    while(n--) {
        string s; cin >> s;
        int cnt = 0;
        bool ok = true;
        for(char c : s) 
        {
            if(c == '(') cnt++;
            else cnt--;
            if(cnt < 0) ok = false;
        }
        if(cnt != 0) ok = false;
        cout << (ok ? "Yes\n" : "No\n");
    }
}