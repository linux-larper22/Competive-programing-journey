#include <bits/stdc++.h>
using namespace std;

bool ok(int x) {
    int t = x;
    while (t) {
        int d = t % 10;
        if (d == 0 || x % d != 0) return false;
        t /= 10;
    }
    return true;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int l, r; cin >> l >> r;

    vector<int> res;
    for (int i = l; i <= r; i++)
        if (ok(i)) res.push_back(i);

    cout << res.size() << "\n";
    for (int x : res) cout << x << " ";
}