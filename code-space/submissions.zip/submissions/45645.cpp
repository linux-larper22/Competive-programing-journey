#include <bits/stdc++.h>
using namespace std;

int main() {
    long long x1, y1, x2, y2, x3, y3;
    
    // Nhập 3 đoạn [x, y]
    cin >> x1 >> y1;
    cin >> x2 >> y2;
    cin >> x3 >> y3;

    // Tìm giao đoạn chung
    long long left = max({x1, x2, x3}); // điểm bắt đầu lớn nhất
    long long right = min({y1, y2, y3}); // điểm kết thúc nhỏ nhất

    if (left > right) 
        cout << 0;           // không có giao đoạn
    else 
        cout << right - left + 1; // độ dài giao đoạn

    return 0;
}