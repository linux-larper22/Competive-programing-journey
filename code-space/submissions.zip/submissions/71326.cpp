#include <bits/stdc++.h>
using namespace std;
const int MAXV = 1e6;
bool isPrime[MAXV+5];
void sieve()
{
    fill(isPrime, isPrime+MAXV+1, true);
    isPrime[0]=isPrime[1]=false;
    for(int i=2;i*i<=MAXV;i++){
        if(isPrime[i]){
            for(int j=i*i;j<=MAXV;j+=i)
                isPrime[j]=false;
        }
    }
}
int main()
{
    sieve();
    int n; cin >> n;
    vector<long long>a(n);
    for(auto &x: a) cin >> x;
    int ans = 0;
    for(int i=0;i<n;i++)
        for(int j=i+1;j<n;j++)
        {
            long long d = abs(a[i]-a[j]);
            if(d <= MAXV && isPrime[d]) ans++;
        }    cout << ans;
}