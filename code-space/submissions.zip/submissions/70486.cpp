#include <bits/stdc++.h>
using namespace std;
int main() 
{
    long long n, k;
    cin >> n >> k;

    long long ans = k * (n - k) + k * (k - 1) / 2;

    cout << ans;
}