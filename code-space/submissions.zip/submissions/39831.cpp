#include<bits/stdc++.h>
using namespace std;
int n, a[200003], b[200002];
int main(){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cin>>n;
    for(int i = 1; i <= n; i++) cin>>a[i];
    for(int i = 1; i <= n; i++) cin>>b[i];
    int ans = 0;
    for(int i = 1; i <= n; i++) ans += (3*a[i]+3*b[i]);
    for(int i = 1; i < n; i++){
        if(a[i]+a[i+1]==2) ans -= 2;
        if(b[i]+b[i+1]==2) ans -= 2;
    }
    for(int i = 1; i <= n; i++)
        if(i%2 == 1 and a[i] + b[i]==2) ans -= 2;
    cout<<ans;
}