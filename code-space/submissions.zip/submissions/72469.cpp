#include <bits/stdc++.h>
using namespace std;
const long long MOD = 123456789;
long long modPow(long long x, long long y)
{
    long long res = 1;
    x %= MOD;
    while (y) {
        if (y & 1) res = (res * x) % MOD;
        x = (x * x) % MOD;
        y >>= 1;
    }
    return res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    long long x, n;
    cin >> x >> n;

    long long ans = 0;
    for (long long i = 1; i <= n; i++) {
        ans = (ans + modPow(x, i)) % MOD;
    }

    cout << ans;
}