#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const ll INF = (ll)4e18;
struct Line {
    ll m, b;
    ll get(ll x) {
        return m * x + b;
    }
};

deque<Line> hull;

bool bad(Line l1, Line l2, Line l3) {
    return (l3.b - l1.b) * (l1.m - l2.m)
         <= (l2.b - l1.b) * (l1.m - l3.m);
}

void add(Line l) {
    while (hull.size() >= 2 && bad(hull[hull.size()-2], hull.back(), l))
        hull.pop_back();
    hull.push_back(l);
}

ll query(ll x) {
    while (hull.size() >= 2 &&
           hull[0].get(x) >= hull[1].get(x))
        hull.pop_front();
    return hull[0].get(x);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;

    vector<ll> a(n+1), pre(n+1,0);
    for(int i=1;i<=n;i++){
        cin >> a[i];
        pre[i]=pre[i-1]+a[i];
    }

    vector<ll> dp_prev(n+1), dp_cur(n+1);

    dp_prev[0]=0;

    for(int j=1;j<=k;j++){
        hull.clear();

        add({-pre[0], dp_prev[0]});

        for(int i=1;i<=n;i++){
            dp_cur[i] = pre[i]*j + query(j);
            add({-pre[i], dp_prev[i]});
        }

        dp_prev = dp_cur;
    }

    cout << dp_prev[n];
}