#include <bits/stdc++.h>
using namespace std;

int x[100005];
int uoc[1000];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    for (int i = 1; i <= n; i++) {
        int y;
        cin >> x[i] >> y;

        int cnt = 0;
        for (int d = 1; d * d <= x[i]; d++) {
            if (x[i] % d == 0) {
                uoc[cnt++] = d;
                if (d * d != x[i])
                    uoc[cnt++] = x[i] / d;
            }
        }

        int dem = 0;
        for (int t = 0; t < cnt; t++) {
            int d = uoc[t];
            bool ok = true;

            for (int j = i - y; j <= i - 1; j++) {
                if (x[j] % d == 0) {
                    ok = false;
                    break;
                }
            }
            if (ok) dem++;
        }

        cout << dem << "\n";
    }
}