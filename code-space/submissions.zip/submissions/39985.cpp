#include <bits/stdc++.h>
using namespace std;

int main() {
    int K;
    cin >> K;

    long long dem = 9;
    for (int i = 2; i <= K; i++) {
        dem = dem * 9; 
    }

    cout << dem;
}