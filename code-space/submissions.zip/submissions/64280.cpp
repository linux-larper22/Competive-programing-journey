#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while(t--) {
        long long n, a, b, c;
        cin >> n >> a >> b >> c;

        long long sum3 = a + b + c;         
        long long full_cycles = n / sum3;   
        long long total = full_cycles * sum3;
        long long day = full_cycles * 3;

        // thêm từng ngày trong chu kỳ tiếp theo
        if(total < n) {
            total += a; day++;
            if(total < n) {
                total += b; day++;
                if(total < n) {
                    total += c; day++;
                }
            }
        }

        cout << day << "\n";
    }

    return 0;
}