#include <bits/stdc++.h>
using namespace std;
const int N = 1e6 + 5;
int n;
int a[N], d[N], ans[N];
int main() 
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        d[a[i]]++;
    }
    ans[1] = n;

    for (int x = 2; x < N; x++) {
        for (int t = x; t < N; t += x) {
            ans[x] += d[t];
        }
    }

    for (int i = 1; i <= n; i++) {
        cout << ans[a[i]] << " ";
    }
}