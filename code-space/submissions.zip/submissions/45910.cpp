#include <bits/stdc++.h>
using namespace std;
const int MAXA = 1000000;
long long bit[MAXA + 5];
long long getSum(int i) 
{
    long long s = 0;
    while (i > 0) 
    {
        s += bit[i];
        i -= i & (-i);
    }
    return s;
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
    long long ans = 0;
    long long total = 0;
    int x;
    for (int i = 1; i <= n; i++) 
    {
        cin >> x;
        ans += total - getSum(x);
        int j = x;
        while (j <= MAXA) 
        {
            bit[j]++;
            j += j & (-j);
        }
       total++;
    }

    cout << ans;
}