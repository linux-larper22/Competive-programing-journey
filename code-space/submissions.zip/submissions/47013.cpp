#include <bits/stdc++.h>
using namespace std;
int last[1000001];
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, k;
    cin >> n >> k;
    for (int i = 0; i <= 1000000; i++) last[i] = -1;
    int ans = 1000000000;
    for (int i = 1; i <= n; i++) 
    {
        int x;
        cin >> x;
        if (last[x] != -1) {
            if (i - last[x] < k) 
            {
                if (x < ans) ans = x;
            }
        }
        last[x] = i;
    }
    if (ans == 1000000000) cout << -1;
    else cout << ans;
}