#include<bits/stdc++.h>
using namespace std;
int n, l[1000002], d[4002], mlen;
int main(){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cin>>n;
    for(int i = 1; i <= n; i++) cin>>l[i];
    for(int i = 1; i <= n; i++) d[l[i]]++;
    //d[x] --> so luong thanh go co do dai bang x ???
    mlen = *max_element(l+1, l+1+n);
    int ans1 = 0, ans2 = 0;
    for(int h = 2; h <= 2*mlen; h++){
        int s = 0;
        for(int x = 1; x < h; x++)
            s += min(d[x], d[h-x]); //x, h-x
        s = s/2;
        //s la so cap ghep duoc ma tong bang h
        if(ans1 < s){
            ans1 = s; ans2 = 1;
        }
        else
        if(ans1 == s){
            ans2++;
        }
    }
    cout<<ans1<<" "<<ans2;
}