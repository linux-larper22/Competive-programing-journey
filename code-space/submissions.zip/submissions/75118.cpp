#include <bits/stdc++.h>
using namespace std;
bool check(int start_digit, const string& S, string& result) 
{
    result = to_string(start_digit);
    int current_digit = start_digit;
    for (char c : S) 
    {
        if (c == '+') current_digit++;
        else if (c == '-') current_digit--;
        if (current_digit < 0 || current_digit > 9) 
        {
            return false;
        }
        result += to_string(current_digit);
    }
    return true;
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string S;
    if (cin >> S) {
        string best_num = "";
        for (int i = 1; i <= 9; ++i) 
        {
            string temp;
            if (check(i, S, temp)) 
            {
                best_num = temp;
                break; 
            }
        }
        if (best_num != "") 
        {
            cout << best_num << "\n";
        } else {
            cout << 0 << "\n";
        }
    }
}