#include <bits/stdc++.h>
using namespace std;

int cnt[26][100005];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    string s;
    cin >> s;
    int n = s.size();

    for (int i = 0; i < n; i++) {
        for (int c = 0; c < 26; c++) {
            cnt[c][i + 1] = cnt[c][i];
        }
        cnt[s[i] - 'a'][i + 1]++;
    }

    int q;
    cin >> q;

    while (q--) {
        int l, r;
        cin >> l >> r;
        r++;

        long long ans = 0;

        for (int c = 0; c < 26; c++) {
            long long x = cnt[c][r] - cnt[c][l];
            ans += x * (x - 1) / 2;
        }

        cout << ans << "\n";
    }
}