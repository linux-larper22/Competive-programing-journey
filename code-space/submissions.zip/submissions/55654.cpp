#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int L, R;
    cin >> L >> R;
    vector<long long> S(R + 1, 1);
    S[0] = 0;
    S[1] = 0;
    for (int i = 2; i <= R / 2; i++) 
    {
        for (int j = i * 2; j <= R; j += i)
            S[j] += i;
    }
    int dem = 0;
    for (int a = L; a <= R; a++) 
    {
        long long b = S[a];
        if (b > a && b <= R && b >= L && S[b] == a)
            dem++;
    }

    cout << dem;
}