#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a; cin >> a;
    bool found = false;
    for(int i=1;i<=a;i++)
    {
        int sum = 0;
        for(int j=1;j*j<=i;j++)
        {
            if(i%j==0){
                sum += j;
                if(j*j != i) sum += i/j;
            }
        }
        if(sum == 2*i){
            cout << i << '\n';
            found = true;
        }
    }

    if(!found) cout << "No perfect";
}