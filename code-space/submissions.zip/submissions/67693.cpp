#include <bits/stdc++.h>
using namespace std;
int cnt[1000005];
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
    vector<int> a(n);
    for (int &x : a) cin >> x;
    vector<int> special;
    for (int d = 1; d <= 9; d++) 
    {
        int num = d;
        while (num <= 2000000) {
            special.push_back(num);
            num = num * 10 + d;
        }
    }
    long long ans = 0;
    for (int i = 0; i < n; i++) 
    {
        for (int x : special) {
            int need = x - a[i];
            if (need >= 0 && need <= 1000000) 
            {
                ans += cnt[need];
            }
        }
        cnt[a[i]]++;
    }

    cout << ans;
}