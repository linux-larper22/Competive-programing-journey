#include <bits/stdc++.h>
using namespace std;

int main(){
    int n, k;
    cin >> n >> k;
    vector<int> a(n);
    for(int &x : a) cin >> x;
    sort(a.begin(), a.end());
    
    int res = INT_MAX;
    for(int removeStart = 0; removeStart <= k; removeStart++){
        int removeEnd = k - removeStart;
        int smax = a[n-1-removeEnd] - a[removeStart];
        res = min(res, smax);
    }
    cout << res << endl;
    return 0;
}