#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    string s;
    cin >> s;
    long long sum = 0;
    int n = s.size();
    for (int i = 0; i < n; i++) {
        if (isdigit(s[i]) || s[i] == '-') 
        {
            int sign = 1;
            if (s[i] == '-') {
                sign = -1;
                i++;
            }
            long long num = 0;
            bool ok = false;
            while (i < n && isdigit(s[i])) 
            {
                num = num * 10 + (s[i] - '0');
                i++;
                ok = true;
            }

            if (ok) sum += sign * num;
            i--; 
        }
    }

    cout << sum;
}