#include <iostream>
using namespace std;
int main() 
{
    int n;
    cin >> n;
    long long a[1005], b[1005];
    int m = 0;
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
        if (a[i] >= 5 && (a[i] - 5) % 3 == 0) 
        {
            b[m] = a[i];
            m++;
        }
    }
    if (m == 0) 
    {
        cout << 0;
        return 0;
    }
    for (int i = 0; i < m - 1; i++)
        for (int j = i + 1; j < m; j++)
            if (b[i] > b[j]) {
                long long t = b[i];
                b[i] = b[j];
                b[j] = t;
            }

    for (int i = 0; i < m; i++)
        cout << b[i] << " ";
}