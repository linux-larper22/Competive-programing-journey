#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    unordered_set<long long>s;
    for(int i=0;i<n;i++)
    {
        long long x;
        cin>>x;
        s.insert(x);
    }
    long long x=0;
    while(s.count(x)) x++;
    cout<<x;
}