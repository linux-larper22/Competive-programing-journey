#include <bits/stdc++.h>
using namespace std;
long long tim_gcd(long long a, long long b) {
    while (b != 0) {
        a %= b;
        long long temp = a;
        a = b;
        b = temp;
    }
    return a;
}
long long tri_tuyet_doi(long long n) {
    if (n < 0) return -n;
    return n;
}

int main() {
    int n;
    if (!(cin >> n)) return 0;

    long long a;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    long long d = tri_tuyet_doi(a - a);
    for (int i = 2; i < n; i++) {
        long long hieu = tri_tuyet_doi(a[i] - a[i-1]);
        if (hieu != 0) {
            if (d == 0) d = hieu;
            else d = tim_gcd(d, hieu);
        }
    }

    cout << d;

    return 0;
}