#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<long long> a(n);
    for (auto &x : a) cin >> x;
    long long res = 0;
    for (int pos = 0; pos < 10; pos++) 
    {
        unordered_map<int, long long> cnt;
        for (auto x : a) 
        {
            int digit = (x / (int)pow(10, pos)) % 10;
            cnt[digit]++;
        }
        for (auto &p : cnt) {
            long long k = p.second;
            res += k * (k - 1) / 2;
        }
    }
    cout << res;
}