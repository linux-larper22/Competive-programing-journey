#include <bits/stdc++.h>
using namespace std;
bool check(string s,string x)
{
    int j=0;
    for(int i=0;i<s.size();i++)
        if(j<x.size() && s[i]==x[j])
            j++;

    return j==x.size();
}
int main()
{
    string s;
    cin>>s;
    int n;
    cin>>n;
    while(n--)
    {
        string x;
        cin>>x;

        cout<<check(s,x)<<endl;
    }
}