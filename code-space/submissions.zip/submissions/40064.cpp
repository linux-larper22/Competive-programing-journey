#include <bits/stdc++.h>
using namespace std;

bool check(int x) {
    string e = to_string(x);
    for (int i = 1; i < e.size(); i++)
        if (e[i - 1] == e[i])
            return false;
    return true;
}

int main() {
    int k, ans = 0;
    cin >> k;

    if (k == 1) {
        cout << 10;
        return 0;
    }

    int mi = 1;
    for (int i = 1; i < k; i++)
        mi *= 10;           // mi = 10^(k-1)

    int ma = mi * 10 - 1;   // ma = 10^k - 1

    for (int x = mi; x <= ma; x++)
        if (check(x))
            ans++;

    cout << ans;
    return 0;
}