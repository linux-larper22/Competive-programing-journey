#include<bits/stdc++.h>
using namespace std;
int n, a[200003];
long long x, y;
int main(){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t;
    cin>>t;
    while(t--){
        cin>>n>>x>>y;
        for(int i = 1; i <= n; i++) cin>>a[i];
        sort(a+1, a+1+n);
        long long s = 0, sum = 0, ans = 0;
        for(int i = 1; i <= n; i++) sum += a[i];//sum = a[1]+...+a[n];
        for(int i = 1; i < n; i++){
                s = sum - a[i];
                long long u = s - y, v = s - x; //u <= a[j] <= v ---> a[1]....a[L] <= u ..... v <= a[R]...a[n]
                int L = lower_bound(a+1, a+1+n, u) - a;
                int R = upper_bound(a+1, a+1+n, v) - a;  //      a[R-1] <= v < a[R]
                if(L < n+1){
                    L = max(L, i+1);
                    R--;
                    if( L <= R) ans += (R-L+1);//a[L]-----a[R] --> so luong so hang thoa man: R - L + 1
                }
        }
        cout<<ans<<'\n';
    }
}