#include <bits/stdc++.h>
using namespace std;

int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(0);

    int n; cin >> n;
    vector<int> a(n);

    for (int &x : a) cin >> x;

    map<pair<int,int>, long long> cnt;
    cnt[{0,0}] = 1;

    int s = 0, sq = 0;
    long long ans = 0;

    for (int i = 0; i < n; i++) 
    {
        s = (s + a[i]) % 7;
        sq = (sq + (a[i] * a[i]) % 7) % 7;

        pair<int,int> key = {s, sq};

        ans += cnt[key];
        cnt[key]++;
    }

    cout << ans;
}