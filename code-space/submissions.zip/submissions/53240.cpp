#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    unordered_map<long long, int> dem;
    for (int i = 0; i < n; i++) 
    {
        long long x; cin >> x;
        dem[x]++;
    }
    int q;
    cin >> q;
    while (q--) 
    {
        long long x;
        cin >> x;
        cout << dem[x] << '\n';
    }
}