#include <iostream>
using namespace std;
int main() {
    int n;
    cin >> n;
    long long A[100005]; 
    for (int i = 0; i < n; i++) {
        cin >> A[i];
    }
    long long minA = A[0];
    long long maxA = A[0];
    for (int i = 1; i < n; i++) {
        if (A[i] < minA) minA = A[i];
        if (A[i] > maxA) maxA = A[i];
    }
    if (minA == maxA) {
        cout << 1 << endl;
        return 0;
    }
    int lastMinPos = -1;   
    int lastMaxPos = -1;  
    int minLength = n + 1; 

    for (int i = 0; i < n; i++) {
        if (A[i] == minA) lastMinPos = i;
        if (A[i] == maxA) lastMaxPos = i;
        if (lastMinPos != -1 && lastMaxPos != -1) {
            int start = lastMinPos < lastMaxPos ? lastMinPos : lastMaxPos;
            int end   = lastMinPos > lastMaxPos ? lastMinPos : lastMaxPos;
            int length = end - start + 1;
            if (length < minLength) {
                minLength = length;
            }
        }
    }
    cout << minLength << endl;
}