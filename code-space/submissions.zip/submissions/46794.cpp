#include <bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int soLuongPhanTu, doDaiDoan;
    cin >> soLuongPhanTu >> doDaiDoan;
    long long* cuaSo = new long long[doDaiDoan]; // mảng vòng
    int dau = 0, kichThuoc = 0;
    long long tongHienTai = 0;
    long long tongNhoNhat = LLONG_MAX;
    int soChan = 0, soLe = 0;
    for (int chiSo = 1; chiSo <= soLuongPhanTu; chiSo++) {
        long long giaTri;
        cin >> giaTri;
        if (kichThuoc < doDaiDoan) {
            cuaSo[kichThuoc++] = giaTri;
            tongHienTai += giaTri;
        } else {
            long long phanTuCu = cuaSo[dau];
            tongHienTai -= phanTuCu;
            if (phanTuCu % 2 == 0) soChan--;
            else soLe--;
            cuaSo[dau] = giaTri;
            tongHienTai += giaTri;
            dau = (dau + 1) % doDaiDoan;
        }
        if (giaTri % 2 == 0) soChan++;
        else soLe++;
        if (kichThuoc == doDaiDoan && soChan >= 1 && soLe >= 1) {
            if (tongHienTai < tongNhoNhat)
                tongNhoNhat = tongHienTai;
        }
    }
    cout << tongNhoNhat;
}