#include <bits/stdc++.h>
using namespace std;
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    if (!(cin >> n)) return 0;
    vector<long long> a(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    long long d = 0;
    for (int i = 1; i < n; ++i) {
        long long hieu = (a[i] > a[i-1]) ? (a[i] - a[i-1]) : (a[i-1] - a[i]);
        if (hieu > 0) {
            if (d == 0) {
                d = hieu;
            } else {
                d = std::gcd(d, hieu);
            }
        }
    }

    cout << d;

    return 0;
}