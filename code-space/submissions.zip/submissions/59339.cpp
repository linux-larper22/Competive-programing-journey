#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int N;
    cin >> N;

    static int d[1000001] = {0};

    for (int i = 0; i < N; i++) {
        int x;
        cin >> x;
        d[x]++;
    }

    int m = 0;
    for (int i = 0; i <= 1000000; i++)
        if (d[i] > 0) m++;

    cout << m << '\n';
    for (int i = 0; i <= 1000000; i++)
        if (d[i] > 0)
            cout << i << " " << d[i] << '\n';

    return 0;
}