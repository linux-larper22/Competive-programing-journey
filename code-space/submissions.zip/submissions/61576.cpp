#include <bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    long long n;
   cin >> n;
    vector<long long> a(n);
    long long sum = 0;
    for(int i=0;i<n;i++)
    {
        cin >> a[i];
        sum += a[i];
    }
    long long low = sum / n;
    long long high = (sum + n - 1) / n;
    long long diff = high - low;
    long long move = 0;
    for(int i=0;i<n;i++)
        if(a[i] > high)
            move += a[i] - high;
    cout << diff << "\n";
    cout << move << "\n";
}