#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;

    vector<long long> a(n + 1);
    vector<long long> S(n + 1, 0);
    vector<long long> Q(n + 1, 0);

    // Mảng đếm cặp (S[i] % 7, Q[i] % 7)
    long long cnt[7][7] = {0};
    cnt[0][0] = 1; // S[0]=0, Q[0]=0

    long long ans = 0;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        S[i] = (S[i - 1] + a[i]) % 7;
        Q[i] = (Q[i - 1] + (a[i] * a[i]) % 7) % 7;
        for (int s = 0; s < 7; s++) {
            for (int q = 0; q < 7; q++) {
                int sum_diff = (S[i] - s + 7) % 7;
                int sq_diff = (Q[i] - q + 7) % 7;
                if ((1LL * sum_diff * sum_diff) % 7 == sq_diff) {
                    ans += cnt[s][q];
                }
            }
        }
        cnt[S[i]][Q[i]]++;
    }

    cout << ans << endl;

    return 0;
}