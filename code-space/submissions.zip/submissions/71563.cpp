#include <bits/stdc++.h>
using namespace std;

#define int long long

int32_t main() {
    int n;
    cin >> n;

    int p, q;
    cin >> p >> q;

    vector<int> a(n + 1), pref(n + 1);

    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        pref[i] = pref[i - 1] + a[i];
    }

    deque<int> dq;

    long long ans = LLONG_MIN;

    for (int r = p; r <= n; r++) {

        int idx = r - p;

        while (!dq.empty() && pref[dq.back()] >= pref[idx])
            dq.pop_back();

        dq.push_back(idx);

        while (!dq.empty() && dq.front() < r - q)
            dq.pop_front();

        ans = max(ans, pref[r] - pref[dq.front()]);
    }

    cout << ans;

    return 0;
}