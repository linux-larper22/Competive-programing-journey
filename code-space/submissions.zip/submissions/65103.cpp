#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) 
    {
    
        int n;
        cin >> n;
        vector<int> a(n);
        for (int &x : a) cin >> x;
        long long res = 0;
        for (int k = 2; k < n; k++) 
        {
            int i = 0, j = k - 1;
            while (i < j) {
                if (a[i] + a[j] > a[k]) 
                {
                    res += (j - i);
                    j--;
                } else i++;
            }
        }

        cout << res << "\n";
    }
}