#include <bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n,m;
    cin >> n >> m;
    unordered_set<long long> s;
    for(int i=0;i<n;i++)
    {
        long long x;
        cin >> x;
        if(x >= 0) s.insert(x);
    }
    for(int i=0;i<m;i++)
    {
        long long x;
        cin >> x;
        if(x >= 0) s.insert(x);
    }
    long long ans = 0;
    while(s.count(ans))
        ans++;
    cout << ans;
}