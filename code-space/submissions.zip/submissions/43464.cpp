#include <bits/stdc++.h>
using namespace std;

int n, k;
pair<int, int> a[100001];

// Hàm so sánh: sắp xếp giảm dần theo first, nếu bằng thì tăng dần theo second
bool comp(pair<int,int> x, pair<int,int> y) {
    if (x.first > y.first) return true;
    if (x.first == y.first) return x.second < y.second;
    return false;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> a[i].first;
        a[i].second = i;
    }

    sort(a + 1, a + n + 1, comp);

    vector<int> v;
    for (int i = 1; i <= k; i++) {
        v.push_back(a[i].second);
    }

    sort(v.begin(), v.end());

    for (int x : v) {
        cout << x << " ";
    }
    cout << "\n";

    return 0;
}