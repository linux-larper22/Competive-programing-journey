#include<bits/stdc++.h>
using namespace std;
int const N = 1e6+1;
bool nt[N];

void sang(){
    memset(nt, true, sizeof nt);
    nt[0] = nt[1] = false;
    for(int i = 2; i*i < N; i++)
        if(nt[i]){
            for(int t = i*i; t < N; t += i)
                nt[t] = false;
        }

}
int main(){
    int n;
    cin>>n;
    sang();
    while(n--){
        long long x;
        cin>>x;
        int mv = min(1e6, sqrt(x));
        for(long long p = 2; p*p <= mv; p++ )
        {
            if(nt[p])
            while(x%(p*p)== 0) x = x/(p*p);
        }
        for(int y = 1; y <= min(x, 1000000LL); y++){
            if(x%y == 0){
                long long u = x/y;//u = p*p
                long long e = sqrt(u);
                if(e*e == u) x = x/u;
            }
        }
        cout<<x<<'\n';
        // x <= 10^18  --> chia x co cac so: p^2 voi p la so nguyen to
        // x = p^2 * y --> y la tich cac so nguyen to; y > 10^6
        //             --> y < 10^6
    }

}