#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int k;
    long long n;
    cin >> k >> n;
    vector<int> d(k);
    for (int i = 0; i < k; i++) cin >> d[i];
    sort(d.begin(), d.end());
    priority_queue<long long, vector<long long>, greater<long long>> pq;
    for (int x : d) pq.push(x);
    long long cnt = 0;
    while (!pq.empty()) 
    {
        long long cur = pq.top();
        pq.pop();
        cnt++;
        if (cnt == n) 
        {
            cout << cur;
            return 0;
        }
        for (int x : d) 
        {
            if (cur <= (LLONG_MAX - x) / 10)
                pq.push(cur * 10 + x);
        }
    }
}