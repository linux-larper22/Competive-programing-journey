#include <bits/stdc++.h>
using namespace std;

const int MAXN = 10000000;

vector<bool> prime;

void sieve() {
    prime.assign(MAXN + 1, true);
    prime[0] = prime[1] = false;

    for (int i = 2; i * i <= MAXN; i++) {
        if (prime[i]) {
            for (int j = i * i; j <= MAXN; j += i)
                prime[j] = false;
        }
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int a, b;
    cin >> a >> b;

    sieve();

    int ans = 0;

    for (int n = a; n <= b; n++) {

        bool ok = false;

        // dạng p^3
        int p = round(cbrt(n));
        if (1LL * p * p * p == n && prime[p])
            ok = true;

        // dạng p*q
        if (!ok) {
            for (int i = 2; 1LL * i * i <= n; i++) {
                if (n % i == 0) {
                    int j = n / i;

                    if (i != j && prime[i] && prime[j]) {
                        ok = true;
                    }
                    break;
                }
            }
        }

        ans += ok;
    }

    cout << ans;
}