#include <bits/stdc++.h>
using namespace std;
static const long long MOD = 1e9 + 7;
long long modpow(long long a, long long e) 
{
    long long r = 1;
    while (e) {
        if (e & 1) r = r * a % MOD;
        a = a * a % MOD;
        e >>= 1;
    }
    return r;
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    long long c0 = 0, c1 = 0, c2 = 0;
    for (int i = 0; i < n; i++) 
    {
        long long x;
        cin >> x;
        int r = x % 3;
        if (r == 0) c0++;
        else if (r == 1) c1++;
        else c2++;
    }
    long long pow2_c0 = modpow(2, c0);
    long long pow2_c12 = modpow(2, c1 + c2);
    long long d = (c1 - c2) % 6;
    if (d < 0) d += 6;
    long long val;
    if (d == 0) val = 2;
    else if (d == 1 || d == 5) val = 1;
    else if (d == 2 || d == 4) val = MOD - 1;
    else val = MOD - 2;
    long long inv3 = modpow(3, MOD - 2);
    long long inner = (pow2_c12 + val) % MOD;
    long long ans = pow2_c0 * inner % MOD;
    ans = ans * inv3 % MOD;
    cout << ans;
}