#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n;
    cin >> n;
    long long ans = 0;
    for (long long l = 1; l <= n; ) 
    {
        long long k = n / l;
        long long r = n / k;  
        ans += (r - l + 1) * k;
        l = r + 1;
    }
    cout << ans;
}