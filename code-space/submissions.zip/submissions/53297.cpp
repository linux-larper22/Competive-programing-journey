#include <bits/stdc++.h>
using namespace std;

int k;
long long n, cnt = 0;
vector<char> d;
bool used[10];
string ans;
bool found = false;

void dfs(string cur) {
    if (found) return;

    if (!cur.empty()) {
        cnt++;
        if (cnt == n) {
            ans = cur;
            found = true;
            return;
        }
    }

    for (int i = 0; i < k; i++) {
        if (!used[i]) {
            used[i] = true;
            dfs(cur + d[i]);
            used[i] = false;
            if (found) return;
        }
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> k >> n;
    d.resize(k);
    for (int i = 0; i < k; i++) cin >> d[i];

    sort(d.begin(), d.end());
    memset(used, false, sizeof(used));

    dfs("");

    cout << ans;
}