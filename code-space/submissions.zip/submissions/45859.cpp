#include <bits/stdc++.h>
using namespace std;
int isPrime[1000005];
int prime[1000005];
int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
    for (int i = 2; i <= n; i++)
        isPrime[i] = 1;
    for (int i = 2; i * i <= n; i++) {
        if (isPrime[i]) {
            for (int j = i * i; j <= n; j += i)
                isPrime[j] = 0;
        }
    }
    int cntPrime = 0;
    for (int i = 2; i <= n; i++) {
        if (isPrime[i])
            prime[cntPrime++] = i;
    }
    long long ans = 0;
    for (int i = 0; i < cntPrime; i++) {
        for (int j = i + 1; j < cntPrime; j++) {
            long long x = 1LL * prime[i] * prime[j];
            if (x <= n)
                ans++;
            else
                break;
        }
    }
    cout << ans;
}