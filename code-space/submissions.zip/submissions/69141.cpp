#include <bits/stdc++.h>
using namespace std;
int main() 
{
    long long x, m;
    cin >> x >> m;
    long long p = 1;
    long long temp = x;
    while (temp > 0) 
    {
        p *= 10;
        temp /= 10;
    }
    if (m < x) {
        cout << 0;
        return 0;
    }
    long long ans = (m - x) / p;
    cout << ans;
    return 0;
}