#include <bits/stdc++.h>
using namespace std;
long long GCD(long long a, long long b) 
{
    while (b != 0) {
        long long r = a % b;
        a = b;
        b = r;
    }
    return a;
}
long long LCM(long long a, long long b) 
{
    return a / GCD(a, b) * b;
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long x, y, z, m;
    cin >> x >> y >> z >> m;
    long long xy = LCM(x, y);
    long long xz = LCM(x, z);
    long long yz = LCM(y, z);
    long long xyz = LCM(xy, z);
    long long ans =
        (m / xy - m / xyz) +
        (m / xz - m / xyz) +
        (m / yz - m / xyz);

    cout << ans;
}