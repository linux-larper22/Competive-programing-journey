#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int k;
    cin >> k;

    int ans = 0;
    while (k--) {
        string s;
        cin >> s;

        int cnt[26] = {0};
        bool ok = true;

        for (char c : s) {
            cnt[c - 'a']++;
            if (cnt[c - 'a'] > 2) {
                ok = false;
                break;
            }
        }

        if (ok) ans++;
    }

    cout << ans;
    return 0;
}