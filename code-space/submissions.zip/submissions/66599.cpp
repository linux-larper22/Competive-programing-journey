#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int n; cin >> n;
    vector<long long> a(n);

    for (auto &x : a) cin >> x;

    vector<long long> cnt(7, 0);
    cnt[0] = 1;

    long long ans = 0;
    long long S = 0, SQ = 0;

    for (int i = 0; i < n; i++) {
        S = (S + a[i]) % 7;
        SQ = (SQ + (a[i] % 7) * (a[i] % 7)) % 7;

        long long val = (S * S - SQ) % 7;
        if (val < 0) val += 7;

        ans += cnt[val];
        cnt[val]++;
    }

    cout << ans;
}