#include<bits/stdc++.h>
using namespace std;
int n;
int main(){
    cin>>n;
    int ans = 0;
    //n = x4 + y5 --> so cap (x, y) thoa man.
    for(int x = 0; x*4 <= n; x++){
        int e = n - 4*x;
        if(e%5 == 0) ans++;
    }
    cout<<ans;
}