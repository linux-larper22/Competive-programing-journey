#include <bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    long long d;
    cin >> n >> d;
    vector<long long> a(n);
    long long mn = LLONG_MAX;
    long long mx = LLONG_MIN;
    for(int i=0;i<n;i++)
    {
        cin >> a[i];
        mn = min(mn,a[i]);
        mx = max(mx,a[i]);
    }
    cout << mx - mn << '\n';
    if(mx - mn <= d)
    {
        cout << 0;
        return 0;
    }
    sort(a.begin(),a.end());
    int l = 0;
    int best = 0;
    for(int r=0;r<n;r++)
    {
        while(a[r]-a[l] > d) l++;
        best = max(best,r-l+1);
    }
    cout << n - best;
}