#include <bits/stdc++.h>
using namespace std;
int main() 
{
    int n;
    cin >> n;
    static int dem[1000001];
    for (int i = 0; i < n; i++) 
    {
        int x;
        cin >> x;
        dem[x]++;
    }
    int m = 0;
    for (int i = 0; i <= 1000000; i++)
        if (dem[i] > 0) m++;
    cout << m << '\n';
    for (int i = 1000000; i >= 0; i--) 
    {
        if (dem[i] > 0) {
            cout << i << " " << dem[i] << '\n';
        }
    }
}