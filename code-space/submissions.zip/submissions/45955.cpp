#include <bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n, k;
    cin >> n >> k;
    int x;
    long long totalGreen = 0;
    int curOnes = 0;
    int minOnes;
    for (int i = 1; i <= k; i++) {
        cin >> x;
        if (x == 1) {
            totalGreen++;
            curOnes++;
        }
    }
    minOnes = curOnes;

    for (int i = k + 1; i <= n; i++) {
        int out, in;
        out = x;    
        cin >> in;      
        if (out == 1) curOnes--;
        if (in == 1) {
            curOnes++;
            totalGreen++;
        }
        minOnes = min(minOnes, curOnes);
        x = in;
    }
    long long ans = totalGreen + (k - 2LL * minOnes);
    cout << ans;
}