#include <bits/stdc++.h>
int main() {
    ios::sync_with_stdio(false);
    std::cin.tie(NULL);
    int T;
    std::cin >> T;
    while (T--) {
        long long a, b, c, d;
        std::cin >> a >> b >> c >> d;
        std::cout << std::max(
                    std::max(llabs(2*a - 3*c), llabs(2*a - 3*d)),
                    std::max(llabs(2*b - 3*c), llabs(2*b - 3*d))
               ) << '\n';
    }
}