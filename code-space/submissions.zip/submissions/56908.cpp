#include <bits/stdc++.h>
using namespace std;
int main() 
{
    int n;
    cin >> n;
    int dem[1001] = {0};
    for (int i = 0; i < n; i++) 
    {
        int x;
        cin >> x;
        dem[x]++;
    }
    for (int i = 1; i <= 1000; i++) 
    {
        if (dem[i] == 2) {
            cout << i << '\n';
        }
    }
}