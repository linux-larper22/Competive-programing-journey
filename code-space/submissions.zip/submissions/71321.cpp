#include <bits/stdc++.h>
using namespace std;
vector<int> pos0A, pos1A, pos0B, pos1B;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n; cin >> n;
    vector<int>a(n);
    for(int i=0;i<n;i++){
        cin >> a[i];
        if(a[i]==0) pos0A.push_back(i);
        else pos1A.push_back(i);
    }
    int m; cin >> m;
    vector<int>b(m);
    for(int i=0;i<m;i++){
        cin >> b[i];
        if(b[i]==0) pos0B.push_back(i);
        else pos1B.push_back(i);
    }
    int ans = 0;
    for(int k=0;k<=min(pos0A.size(), pos0B.size());k++){
        int cutA = (k==0 ? -1 : pos0A[k-1]);
        int cutB = (k==0 ? -1 : pos0B[k-1]);
        int onesA = pos1A.end() - upper_bound(pos1A.begin(), pos1A.end(), cutA);
        int onesB = pos1B.end() - upper_bound(pos1B.begin(), pos1B.end(), cutB);
        ans = max(ans, k + min(onesA, onesB));
    }
    cout << ans;
}