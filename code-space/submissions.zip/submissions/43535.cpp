#include <bits/stdc++.h>
using namespace std;

long long n, a[100002];

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    cin >> n;
    for (int i = 1; i <= n; i++) 
        cin >> a[i];

    sort(a + 1, a + 1 + n);

    long long ans = 0;
    for (int i = 1; i <= n; i++)
        ans = max(ans, a[i] * (n - i + 1));

    cout << ans;

}