#include <bits/stdc++.h>
using namespace std;
using ll = long long;

ll k, cnt;

ll f(ll n) {
    if (n < 0) return 0;
    ll blocks = n / 100;
    ll res = blocks * cnt;

    ll rem = n % 100;
    res += rem / k + 1;

    return res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T >> k;

    cnt = 99 / k + 1;

    while (T--) {
        ll a, b;
        cin >> a >> b;
        cout << f(b) - f(a - 1) << '\n';
    }
}