#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    long long x;
    int cur = 0, ans = 0;
    int sign = 0; 
    for (int i = 1; i <= n; i++) 
    {
        cin >> x;
        if (x == 0) {
            cur = 0;
            sign = 0;
        }
        else 
        {
            int s = (x > 0 ? 1 : -1);
            if (s == sign)
                cur++;
            else {
                cur = 1;
                sign = s;
            }
            ans = max(ans, cur);
        }
    }
    cout << ans;
}