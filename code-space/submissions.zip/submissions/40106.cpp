#include <bits/stdc++.h>
using namespace std;

long long A[1000005], sum[1000005], leftMax[1000005], rightMax[1000005];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int n, k;
    cin >> n >> k;

    for (int i = 1; i <= n; i++) cin >> A[i];

    int m = n - k + 1;
    long long s = 0;
    for (int i = 1; i <= k; i++) s += A[i];
    sum[1] = s;
    for (int i = 2; i <= m; i++) {
        s = s - A[i - 1] + A[i + k - 1];
        sum[i] = s;
    }


    leftMax[1] = sum[1];
    for (int i = 2; i <= m; i++)
        leftMax[i] = max(leftMax[i - 1], sum[i]);

    rightMax[m] = sum[m];
    for (int i = m - 1; i >= 1; i--)
        rightMax[i] = max(rightMax[i + 1], sum[i]);

    long long ans = 0;
    for (int j = k + 1; j <= m - k; j++) {
        long long total = leftMax[j - k] + sum[j] + rightMax[j + k];
        if (total > ans) ans = total;
    }

    cout << ans;
}