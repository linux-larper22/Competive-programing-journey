#include <bits/stdc++.h>
using namespace std;

const int MAXA = 1000000;

int mu[MAXA+1];
bool prime[MAXA+1];
int cnt[MAXA+1];
int f[MAXA+1];

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    cin>>n;

    vector<int>a(n);

    for(int i=0;i<n;i++){
        cin>>a[i];
        cnt[a[i]]++;
    }

    // mobius
    for(int i=1;i<=MAXA;i++) mu[i]=1;

    for(int i=2;i<=MAXA;i++){
        if(!prime[i]){
            for(int j=i;j<=MAXA;j+=i){
                prime[j]=1;
                mu[j]*=-1;
            }

            long long sq=1LL*i*i;
            if(sq<=MAXA)
            for(long long j=sq;j<=MAXA;j+=sq)
                mu[j]=0;
        }
    }

    // đếm số chia hết cho d
    for(int d=1;d<=MAXA;d++){
        for(int j=d;j<=MAXA;j+=d)
            f[d]+=cnt[j];
    }

    long long ans=0;

    for(int d=1;d<=MAXA;d++){
        long long c=f[d];
        ans += 1LL*mu[d]*c*(c-1)/2;
    }

    cout<<ans;
}