#include <bits/stdc++.h>
using namespace std;
int main() 
{
    string s;
    cin >> s;
    int n = s.size();
    long long L[3] = {0}, R[3] = {0};
    for (char c : s) {
        if (c == 'a') R[0]++;
        if (c == 'b') R[1]++;
        if (c == 'c') R[2]++;
    }
    long long ans = 0;
    for (char c : s) {
        if (c == 'a') R[0]--;
        if (c == 'b') R[1]--;
        if (c == 'c') R[2]--;
        if (c == 'a')
            ans += L[1] * R[2] + L[2] * R[1];
        if (c == 'b')
            ans += L[0] * R[2] + L[2] * R[0];
        if (c == 'c')
            ans += L[0] * R[1] + L[1] * R[0];
        if (c == 'a') L[0]++;
        if (c == 'b') L[1]++;
        if (c == 'c') L[2]++;
    }
    cout << ans;
}