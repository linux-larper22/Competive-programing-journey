#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m;
    cin >> n >> m;
    vector<long long> A(n), B(m);
    long long Sa = 0, Sb = 0;
    for (int i = 0; i < n; i++) 
    {
        cin >> A[i];
        Sa += A[i];
    }
    for (int i = 0; i < m; i++) 
    {
        cin >> B[i];
        Sb += B[i];
    }
    long long D = Sa - Sb;
    long long ans = llabs(D);   
    for (int i = 0; i < n; i++) 
    {
        for (int j = 0; j < m; j++) {
            long long cur = llabs(D - 2 * (A[i] - B[j]));
            ans = min(ans, cur);
        }
    }
    if (n >= 2 && m >= 2) {
        vector<long long> sumA, sumB;
        for (int i = 0; i < n; i++)
            for (int j = i + 1; j < n; j++)
                sumA.push_back(A[i] + A[j]);
        for (int i = 0; i < m; i++)
            for (int j = i + 1; j < m; j++)
                sumB.push_back(B[i] + B[j]);
        sort(sumA.begin(), sumA.end());
        sort(sumB.begin(), sumB.end());
        int i = 0, j = (int)sumB.size() - 1;
        while (i < (int)sumA.size() && j >= 0) 
        {
            long long diff = D - 2 * (sumA[i] - sumB[j]);
            ans = min(ans, llabs(diff));
            if (2 * (sumA[i] - sumB[j]) > D)
                j--;
            else
                i++;
        }
    }
    cout << ans;
}