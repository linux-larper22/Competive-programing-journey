#include <bits/stdc++.h>
using namespace std;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int soLuongA, soLuongB, doDaiDoan;
    cin >> soLuongA >> soLuongB >> doDaiDoan;
    long long* dayA = new long long[soLuongA];
    for (int i = 0; i < soLuongA; i++) cin >> dayA[i];
    long long* dayB = new long long[soLuongB];
    for (int i = 0; i < soLuongB; i++) cin >> dayB[i];
    int soDoanA = soLuongA - doDaiDoan + 1;
    int soDoanB = soLuongB - doDaiDoan + 1;
    long long* tongA = new long long[soDoanA];
    long long* tongB = new long long[soDoanB];
    long long tong = 0;
    for (int i = 0; i < soLuongA; i++) {
        tong += dayA[i];
        if (i >= doDaiDoan) tong -= dayA[i - doDaiDoan];
        if (i >= doDaiDoan - 1)
            tongA[i - doDaiDoan + 1] = tong;
    }
    tong = 0;
    for (int i = 0; i < soLuongB; i++) {
        tong += dayB[i];
        if (i >= doDaiDoan) tong -= dayB[i - doDaiDoan];
        if (i >= doDaiDoan - 1)
            tongB[i - doDaiDoan + 1] = tong;
    }
    sort(tongB, tongB + soDoanB);
    long long ketQua = LLONG_MAX;
    for (int i = 0; i < soDoanA; i++) {
        long long giaTriA = tongA[i];
        int viTri = lower_bound(tongB, tongB + soDoanB, giaTriA) - tongB;
        if (viTri < soDoanB)
            ketQua = min(ketQua, llabs(giaTriA - tongB[viTri]));
        if (viTri > 0)
            ketQua = min(ketQua, llabs(giaTriA - tongB[viTri - 1]));
    }
    cout << ketQua;
}