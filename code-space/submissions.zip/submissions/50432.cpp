#include <bits/stdc++.h>
using namespace std;
int main() 
{
    int n;
    cin >> n;
    long long x, y;
    cin >> x;
    int cur = (x != 0);
    int best = cur;
    for (int i = 2; i <= n; i++) 
    {
        cin >> y;
        if (y != 0 && (x > 0) == (y > 0))
            cur++;
        else
            cur = (y != 0);
        if (cur > best) best = cur;
        x = y;
    }
    cout << best;
}