#include <bits/stdc++.h>
using namespace std;
bool coUocChinhPhuong(long long a, long long b) 
{
    unordered_map<long long, int> dem;
    long long x = a;
    for (long long p = 2; p * p <= x; p++) 
    {
        while (x % p == 0) {
            dem[p]++;
            if (dem[p] >= 2) return true;
            x /= p;
        }
    }
    if (x > 1) dem[x]++;
    x = b;
    for (long long p = 2; p * p <= x; p++) 
    {
        while (x % p == 0) 
        {
            dem[p]++;
            if (dem[p] >= 2) return true;
            x /= p;
        }
    }
    if (x > 1 && ++dem[x] >= 2) return true;
    return false;
}
int main() 
{
    long long L, R;
    cin >> L >> R;
    long long demCap = 0;
    for (long long a = L; a < R; a++) 
    {
        for (long long b = a + 1; b <= R; b++) 
        {
            if (coUocChinhPhuong(a, b))
                demCap++;
        }
    }
    cout << demCap;
}