#include <bits/stdc++.h>
using namespace std;
long long n,a[1000002];
int main() {
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0)
    cin>>n;
 for(int i=1;i<=n;i++) cin>>a[i];
 sort (a+1,a+1+n);
 long long x=a[1]*a[n];
 long y=a[1]*a[2];
 long z=a[n-1]*a[n];
 long long ans = min({x,y,x});
 cout<<ans;
 
}