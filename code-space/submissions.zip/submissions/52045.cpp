#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    long long x;
    cin >> n >> x;
    long long ans = LLONG_MAX, a;
    for (int i = 0; i < n; i++) 
    {
        cin >> a;
        if (a % x == 0) 
        {
            ans = min(ans, a);
        }
    }
    cout << ans;
}