#include <bits/stdc++.h>
using namespace std;
int main() 
{
    long long m, n;
    cin >> m >> n;
    if (n % m != 0) 
    {
        cout << -1;
        return 0;
    }
    long long t = n / m;
    long long ans = LLONG_MAX;
    for (long long x = 1; x * x <= t; x++) 
    {
        if (t % x == 0) {
            long long y = t / x;
            if (__gcd(x, y) == 1) 
            {
                ans = min(ans, m * (x + y));
            }
        }
    }

    if (ans == LLONG_MAX) cout << -1;
    else cout << ans;

    return 0;
}