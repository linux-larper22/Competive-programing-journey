#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int soNguoi;
    cin >> soNguoi;
    unordered_map<long long, long long> demMau;
    for (int i = 0; i < soNguoi; i++) 
    {
        long long mauAo;
        cin >> mauAo;
        demMau[mauAo]++;
    }
    if (demMau.size() < 2) 
    {
        cout << 0;
        return 0;
    }
    vector<long long> danhSachTanSuat;
    for (auto &p : demMau)
        danhSachTanSuat.push_back(p.second);
    sort(danhSachTanSuat.begin(), danhSachTanSuat.end(), greater<long long>());
    cout << min(danhSachTanSuat[0], danhSachTanSuat[1]);
    return 0;
}