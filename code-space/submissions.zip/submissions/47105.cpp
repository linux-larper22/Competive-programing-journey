#include <bits/stdc++.h>
using namespace std;
int pref[1000005];
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, q;
    cin >> n >> q;
    string s;
    cin >> s;
    pref[0] = 0;
    for (int i = 0; i < n; i++) 
    {
        int bit = s[i] - 'a';
        pref[i + 1] = pref[i] ^ (1 << bit);
    }
    while (q--) 
    {
        int l, r;
        cin >> l >> r;
        int cur = pref[r + 1] ^ pref[l];
        int odd = __builtin_popcount(cur);
        int ans = 0;
        if (odd > 1) ans = (odd - 1) / 2;
        cout << ans << '\n';
    }
}