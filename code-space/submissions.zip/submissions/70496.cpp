#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    vector<int> a(n + 1);

    for (int i = 1; i <= n; i++)
        cin >> a[i];

    int m;
    cin >> m;

    vector<int> b(m + 1);

    for (int i = 1; i <= m; i++)
        cin >> b[i];
    vector<int> pos0A(1, 0), pos0B(1, 0);

    for (int i = 1; i <= n; i++)
        if (a[i] == 0)
            pos0A.push_back(i);

    for (int i = 1; i <= m; i++)
        if (b[i] == 0)
            pos0B.push_back(i);

    // suffix số 1
    vector<int> suf1A(n + 2, 0), suf1B(m + 2, 0);

    for (int i = n; i >= 1; i--)
        suf1A[i] = suf1A[i + 1] + (a[i] == 1);

    for (int i = m; i >= 1; i--)
        suf1B[i] = suf1B[i + 1] + (b[i] == 1);

    int maxZero = min((int)pos0A.size() - 1,
                      (int)pos0B.size() - 1);

    int ans = 0;

    for (int z = 0; z <= maxZero; z++) {

        int pA = pos0A[z];
        int pB = pos0B[z];

        int oneA = suf1A[pA + 1];
        int oneB = suf1B[pB + 1];

        ans = max(ans, z + min(oneA, oneB));
    }

    cout << ans;
}