#include <bits/stdc++.h>
using namespace std;
int k;
long long n;
vector<int> d;
bool used[10];
vector<long long> all;
void dfs(long long cur) {
    if (cur > 0) all.push_back(cur);
    if ((int)all.size() > 1000000) return;
    for (int i = 0; i < k; i++) 
    {
        if (!used[i]) {
            used[i] = true;
            dfs(cur * 10 + d[i]);
            used[i] = false;
        }
    }
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> k >> n;
    d.resize(k);
    for (int i = 0; i < k; i++) cin >> d[i];
    sort(d.begin(), d.end());
    memset(used, false, sizeof(used));
    dfs(0);
    sort(all.begin(), all.end());
    cout << all[n - 1];
}