#include <bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int T;
    cin >> T;
    while(T--)
    {
        int n;
        cin >> n;
        int cnt = 0;
        while(n > 1)
        {
            n = (n + 1) / 2;
            cnt++;
        }
        cout << cnt << "\n";
    }
}