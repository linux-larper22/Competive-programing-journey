#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<long long> a(n + 1);
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    int q;
    cin >> q;
    while (q--) 
    {
        int l, r;
        cin >> l >> r;
        long long mn = a[l];
        long long mx = a[l];
        for (int i = l; i <= r; i++)
        {
            mn = min(mn, a[i]);
            mx = max(mx, a[i]);
        }
        cout << mn * mx << '\n';
    }
}