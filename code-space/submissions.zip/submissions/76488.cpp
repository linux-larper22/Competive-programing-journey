#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while(T--) 
    {
        unsigned long long n;
        cin >> n;
    if(n == 0) cout << 1;
    else if(n == 1) cout << 1;
    else if(n == 2) cout << 2;
    else if(n == 3) cout << 6;
    else if(n == 4) cout << 6;
    else if(n == 5) cout << 3;
    else cout << 9;
        cout << '\n';
    }
}