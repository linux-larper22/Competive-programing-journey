#include <bits/stdc++.h>
using namespace std;

long long C2(long long x) {
    return x * (x - 1) / 2;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    vector<int> a1(n), a2(n);
    for (int i = 0; i < n; i++) cin >> a1[i];
    for (int i = 0; i < n; i++) cin >> a2[i];

    unordered_map<int, long long> cnt1, cnt2;
    map<pair<int,int>, long long> cnt_pair;

    for (int i = 0; i < n; i++) {
        cnt1[a1[i]]++;
        cnt2[a2[i]]++;
        cnt_pair[{a1[i], a2[i]}]++;
    }

    long long res = 0;

    for (auto &x : cnt1) res += C2(x.second);
    for (auto &x : cnt2) res += C2(x.second);
    for (auto &x : cnt_pair) res -= C2(x.second);

    cout << res;
}