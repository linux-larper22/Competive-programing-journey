#include <bits/stdc++.h>
using namespace std;
using int64 = long long;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    int64 k;
    cin >> n >> k;
    vector<int64> a(n);
    unordered_set<int64> s;
    for (int i = 0; i < n; i++) 
    {
        cin >> a[i];
        s.insert(a[i]);
    }
    int ans = 0;
    for (int64 x : a) 
    {
        if (s.count(x - k) && s.count(x + k))
            ans++;
    }

    cout << ans;
}