#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
   long long total = 1LL * n * (n + 1) / 2;
    long long bad = 0;
    long long prev, x;
    cin >> prev;
    long long cnt = 1;
    for (int i = 2; i <= n; i++) 
    {
        cin >> x;
        if (x == prev) 
        {
            cnt++;
        }
        else 
        {
            bad += cnt * (cnt + 1) / 2;
            cnt = 1;
            prev = x;
        }
    }
    bad += cnt * (cnt + 1) / 2;
    cout << total - bad;
}