#include <bits/stdc++.h>
using namespace std;
bool hasTwoIdenticalDigits(long long x) 
{
    if (x < 10) return false; 
    int count[10] = {0}; 
    while (x > 0) {
        count[x % 10]++;
        x /= 10;
    }
    for (int i = 0; i < 10; i++) 
    {
        if (count[i] >= 2) {
            return true;
        }
    }
    return false;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
    int ans = 0;
    for (int i = 0; i < n; i++) 
    {
        long long a;
        cin >> a;
        if (hasTwoIdenticalDigits(a)) 
        {
            ans++;
        }
    }

    cout << ans << "\n";
}