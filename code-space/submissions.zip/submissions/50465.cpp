#include <bits/stdc++.h>
using namespace std;
int main() 
{
    int n;
    cin >> n;
    long long a[200005];
    for (int i = 0; i < n; i++) cin >> a[i];
    int best = 2, cur = 2;
    long long d = a[1] - a[0];
    for (int i = 2; i < n; i++) 
    {
        long long nd = a[i] - a[i - 1];
        if (nd == d) cur++;
        else {
            d = nd;
            cur = 2;
        }
        if (cur > best) best = cur;
    }
    cout << best;
}