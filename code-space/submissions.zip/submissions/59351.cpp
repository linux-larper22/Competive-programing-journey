#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    string s;
    cin >> s;

    int k;
    cin >> k;

    int n = s.length();
    int cntChar[26] = {0};

    // Cửa sổ đầu tiên
    for (int i = 0; i < k; i++)
        cntChar[s[i] - 'a']++;

    int best = -1;
    int countBest = 0;

    auto calc_diff = [&]() {
        int mn = INT_MAX, mx = 0;
        for (int i = 0; i < 26; i++) {
            if (cntChar[i] > 0) {
                mn = min(mn, cntChar[i]);
                mx = max(mx, cntChar[i]);
            }
        }
        return mx - mn;
    };

    int diff = calc_diff();
    best = diff;
    countBest = 1;
    for (int i = k; i < n; i++) {
        cntChar[s[i - k] - 'a']--; 
        cntChar[s[i] - 'a']++;     

        diff = calc_diff();
        if (diff > best) {
            best = diff;
            countBest = 1;
        } else if (diff == best) {
            countBest++;
        }
    }
    cout << best << '\n';
    cout << countBest;
}