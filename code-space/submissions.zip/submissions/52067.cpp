#include <bits/stdc++.h>
using namespace std;
long long GCD(long long a, long long b) 
{
    while (b != 0) 
    {
        long long r = a % b;
        a = b;
        b = r;
    }
    return a;
}
long long LCM(long long a, long long b) 
{
    return a / GCD(a, b) * b;
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long x, y, m;
    cin >> x >> y >> m;
    long long l = LCM(x, y);
    long long ans = m / x + m / y - 2 * (m / l);
    cout << ans;
}