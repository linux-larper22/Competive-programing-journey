#include <bits/stdc++.h>
using namespace std;
int n, a[100005];
int cnt[1000005];
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    cin >> n;
    int mx = 0;

    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        cnt[a[i]]++;
        if (a[i] > mx) mx = a[i];
    }

    int ans = 1;
    for (int g = mx; g >= 1; g--) {
        int dem = 0;
        for (int k = g; k <= mx; k += g)
            dem += cnt[k];
        if (dem >= 2) {
            ans = g;
            break;
        }
    }
    cout << ans;
}