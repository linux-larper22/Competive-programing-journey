#include <bits/stdc++.h>
using namespace std;
int main() 
{
    string s;
    cin >> s;
    int dem[26] = {0};
    for (char c : s)
    {
        dem[c - 'a']++;
    }
    for (int i = 0; i < 26; i++) 
    {
        cout << dem[i] << " ";
    }
}