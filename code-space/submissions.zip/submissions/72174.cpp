#include<bits/stdc++.h>
using namespace std;
int n;
bool check(int x){
    if( x <= 9) return true;
    vector<int> e;
    int y = x;
    while(y > 0){ e.push_back(y%10); y = y/10; }
    int k = e.size();
    int s = 0;
    for(int x: e) s += pow(x, k);//= x^k
    return s == x;
}
int main(){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cin>>n;
    for(int x = 0; x <= n; x++)
        if(check(x)) cout<<x<<'\n';
}