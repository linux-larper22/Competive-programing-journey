#include <bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    while(n--)
    {
        long long x;
        cin >> x;
        bool first = true;
        for(long long p = 2; p * p <= x; p++)
        {
            if(x % p == 0)
            {
                if(!first) cout << ' ';
                cout << p;
                first = false;
                while (x % p == 0) x /= p;
            }
        }

        if(x > 1)
        {
            if(!first) cout << ' ';
            cout << x;
        }
        cout << '\n';
    }
}