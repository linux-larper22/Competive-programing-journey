#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    vector<int> a(n + 1);

    for (int i = 1; i <= n; i++) cin >> a[i];

    int m;
    cin >> m;

    vector<int> b(m + 1);

    for (int i = 1; i <= m; i++) cin >> b[i];

    vector<int> preA(n + 1), preB(m + 1);

    for (int i = 1; i <= n; i++) {
        preA[i] = preA[i - 1] + (a[i] == 0);
    }

    for (int i = 1; i <= m; i++) {
        preB[i] = preB[i - 1] + (b[i] == 0);
    }

    int total1A = 0, total1B = 0;

    for (int i = 1; i <= n; i++)
        total1A += (a[i] == 1);

    for (int i = 1; i <= m; i++)
        total1B += (b[i] == 1);

    int ans = 0;

    for (int z = 0; z <= min(preA[n], preB[m]); z++)
    {

        int oneA = total1A;
        int oneB = total1B;

        ans = max(ans, z + min(oneA, oneB));
    }

    cout << ans;
}