#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while(t--){
        int n;
        long long x, y;
        cin >> n >> x >> y;
        vector<long long> a(n);
        for(int i=0;i<n;i++) cin >> a[i];
        sort(a.begin(), a.end());
        long long total = accumulate(a.begin(), a.end(), 0LL);
        long long count = 0;

        for(int i=0;i<n;i++){
            long long low = total - y - a[i];
            long long high = total - x - a[i];
            int l = lower_bound(a.begin()+i+1, a.end(), low) - a.begin();
            int r = upper_bound(a.begin()+i+1, a.end(), high) - a.begin();
            count += max(0, r-l);
        }
        cout << count << '\n';
    }
    return 0;
}