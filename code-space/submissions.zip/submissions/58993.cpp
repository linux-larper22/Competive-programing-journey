#include <bits/stdc++.h>
using namespace std;
int main() 
{
    int n;
    cin >> n;
    long long dem[11] = {0};
    for (int i = 0; i < n; i++) 
    {
        int x;
        cin >> x;
        dem[x]++;
    }
    long long ans = 0;
    for (int i = 0; i <= 10; i++) 
    {
        for (int j = i; j <= 10; j++) 
        {
            int k = 10 - i - j;
            if (k < j || k > 10) continue;
            if (i == j && j == k) 
            {
                ans += dem[i] * (dem[i] - 1) * (dem[i] - 2) / 6;
            } else if (i == j) 
            {
                ans += dem[i] * (dem[i] - 1) / 2 * dem[k];
            } else if (j == k) 
            {
                ans += dem[j] * (dem[j] - 1) / 2 * dem[i];
            } else 
            {
                
                ans += dem[i] * dem[j] * dem[k];
            }
        }
    }
    cout << ans;
}