#include <bits/stdc++.h>
using namespace std;
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
    vector<long long> result;
    for (int i = 0; i < n; i++) 
    {
        long long x;
        cin >> x;
        if (x >= 5 && (x - 5) % 3 == 0) 
        {
            result.push_back(x);
        }
    }
    sort(result.begin(), result.end());
    if (result.empty()) {
        cout << 0 << "\n";
    } else 
    {
        for (size_t i = 0; i < result.size(); i++) 
        {
            cout << result[i] << (i == result.size() - 1 ? "" : " ");
        }
        cout << "\n";
    }
}