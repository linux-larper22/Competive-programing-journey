#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int N;
    cin >> N;
    long long total = 0;
    while (N--) 
    {
        string s;
        cin >> s;
        char name = s[0];    
        int mn = 9;            
        for (int i = 1; i < (int)s.size(); i++) {
            int price = s[i] - '0';
            mn = min(mn, price);
        }
        cout << name << mn << '\n';
        total += mn;
    }
    cout << total;
}