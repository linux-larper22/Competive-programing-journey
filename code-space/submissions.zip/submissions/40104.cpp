#include <bits/stdc++.h>
using namespace std;

long long A[1000005], sum[1000005], leftMax[1000005], rightMax[1000005];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    cin >> n >> k;

    for (int i = 1; i <= n; i++) cin >> A[i];

    long long cur = 0;
    for (int i = 1; i <= k; i++) cur += A[i];
    sum[1] = cur;

    for (int i = 2; i <= n - k + 1; i++) {
        cur += A[i + k - 1] - A[i - 1];
        sum[i] = cur;
    }

    int m = n - k + 1;
    leftMax[1] = sum[1];
    for (int i = 2; i <= m; i++)
        leftMax[i] = max(leftMax[i - 1], sum[i]);

   
    for (int i = m - 1; i >= 1; i--)
        rightMax[i] = max(rightMax[i + 1], sum[i]);

    long long ans = 0;
    for (int j = k + 1; j <= m - k; j++) {
        long long total = leftMax[j - k] + sum[j] + rightMax[j + k];
        if (total > ans) ans = total;
    }

    cout << ans;
}