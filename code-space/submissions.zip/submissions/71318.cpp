#include <bits/stdc++.h>
using namespace std;

long long cnt[70], pref[70];

bool ok(long long x){
    return (x % 10) == (x % 7);
}

long long get(long long x){
    if(x < 0) return 0;
    long long full = x / 70;
    long long rem = x % 70;
    return full * pref[69] + pref[rem];
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    for(int i=0;i<70;i++){
        cnt[i] = ok(i);
        pref[i] = cnt[i] + (i?pref[i-1]:0);
    }
    int T; cin >> T;
    while(T--)
    {
        long long L, R;
        cin >> L >> R;
        cout << get(R) - get(L-1) << "\n";
    }
}