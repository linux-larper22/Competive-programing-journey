include <bits/stdc++.h>
using namespace std;

int main() {
    int K;
    cin >> K;
    long long ans = 3;
    for (int i = 2; i <= K; i++) ans *= 2;
    
    cout << ans;
    return 0;
}