#include<bits/stdc++.h>
using namespace std;
int main(){
    string s, t, ans = "no";
    cin>>t>>s;
    int n = s.size();
    for(int i = 1; i <= n; i++){
        if(t.find(s) != string::npos)
        {
            ans = "yes"; break;
        }
        s = s + s[0];
        s.erase(0, 1);
    }
    cout<<ans;
}