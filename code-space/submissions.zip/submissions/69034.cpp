#include <bits/stdc++.h>
using namespace std;
int main() 
{
    long long n;
    cin >> n;
    vector<pair<long long, long long>> res;
    for (long long x = 1; x * x <= n; x++) 
    {
        if (n % x == 0) {
            long long y = n / x;
            if (__gcd(x, y) == 1) 
            {
                res.push_back({x, y});
            }
        }
    }

    cout << res.size() << endl;
    for (auto p : res) {
        cout << p.first << " " << p.second << endl;
    }

    return 0;
}