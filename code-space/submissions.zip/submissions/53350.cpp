#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int k;
    long long n;
    cin >> k >> n;
    vector<char> d;
    while ((int)d.size() < k) 
    {
        char c;
        cin >> c;
        if (c >= '1' && c <= '9')
            d.push_back(c);
    }
    sort(d.begin(), d.end());
    long long cnt = 0;
    long long pw = 1;
    int len = 0;
    while (true)
    {
        pw *= k;
        if (cnt + pw >= n){
            len++;
            break;
        }
        cnt += pw;
        len++;
    }
    long long rank = n - cnt - 1; 
    string ans(len, '0');
    for (int i = len - 1; i >= 0; i--) 
    {
        ans[i] = d[rank % k];
        rank /= k;
    }
    cout << ans;
}