#include <bits/stdc++.h>
using namespace std;
int main() 
{
    std::ios_base::sync_with_stdio(false); 
    std::cin.tie(NULL);         
    int n;
    cin >> n;
    const int MAXA = 1000000;
    static int cnt[MAXA + 1];
    static int a[1000005];
    for (int i = 0; i < n; i++) 
    {
        cin >> a[i];
        cnt[a[i]]++;
    }
    for (int i = 0; i < n; i++) 
    {
        int x = a[i];
        int s = 0;
        for (int k = x; k <= MAXA; k += x)
            s += cnt[k];
        cout << s << " ";
    }
}