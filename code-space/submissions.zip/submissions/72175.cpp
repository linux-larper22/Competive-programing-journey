#include<bits/stdc++.h>
using namespace std;
int n, m, a[200002], b[200002], sa[200002], sb[200002];
vector<int> pa, pb;
int main(){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cin>>n;
    for(int i = 1; i <= n; i++) cin>>a[i];
    cin>>m;
    for(int i = 1; i <= m; i++) cin>>b[i];
    int x = count(a+1, a+1+n, 0);
    int y = count(b+1, b+1+m, 0);
    int ans = min(x, y);
    ans = max(ans, min(n-x, m-y));
    for(int i = 1; i <= n; i++) sa[i] = sa[i-1] + a[i];
    for(int i = 1; i <= m; i++) sb[i] = sb[i-1] + b[i];
    for(int i = 1; i <= n; i++)
        if(a[i] == 0) pa.push_back(i);
    for(int i = 1; i <= m; i++)
        if(b[i] == 0) pb.push_back(i);
    for(int e = 1; e <= min(x, y); e++){
        int i = pa[e-1];//a[1] ---- a[i] --> co e so 0, a[i] = 0
        int j = pb[e-1];//b[1] ---- b[j] --> co e so 0, b[j] = 0
        int u = sa[n] - sa[i];
        int v = sb[m] - sb[j];
        int re = min(u, v);
        ans = max(ans, e + re);
    }
    cout<<ans;
}