#include <bits/stdc++.h>
using namespace std;
int k;
long long dp1[44], dp2[44], dp3[44];

int main() {

    cin >> k;

    dp1[1] = dp2[1] = dp3[1] = 1;

    for (int i = 2; i <= k; i++) {
        dp1[i] = dp2[i - 1] + dp3[i - 1]; // (1)
        dp2[i] = dp1[i - 1] + dp3[i - 1]; // (2)
        dp3[i] = dp1[i - 1] + dp2[i - 1]; // (3)
    }

    cout << dp1[k] + dp2[k] + dp3[k];
}