#include <iostream>
#include <vector>
using namespace std;
int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    long long S;
    if (!(cin >> n >> S)) return 0;
    int count = 1;
    long long current_sum = 0;
    for (int i = 0; i < n; ++i) 
    {
        long long a;
        cin >> a;
        if (current_sum + a <= S) 
        {
            current_sum += a;
        } else {
            count++;
            current_sum = a;
        }
    }
    cout << count << "\n";

}