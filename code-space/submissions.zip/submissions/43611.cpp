#include <bits/stdc++.h>
using namespace std;
long long a[1000002]; 
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    int max1 = -40001, max2 = -40001;
    int min1 = 40001, min2 = 40001;   
    int maxNeg1 = -40001, maxNeg2 = -40001; 
    int minNeg1 = 40001, minNeg2 = 40001;   
    for (int i = 1; i <= n; i++) {
        int x = a[i];
        if (x > max1) { max2 = max1; max1 = x; }
        else if (x > max2) { max2 = x; }
        if (x < min1) { min2 = min1; min1 = x; }
        else if (x < min2) { min2 = x; }
        if (x < 0) {
            if (x > maxNeg1) { maxNeg2 = maxNeg1; maxNeg1 = x; }
            else if (x > maxNeg2) { maxNeg2 = x; }
        }
    }
    long long ans = LLONG_MAX;
    ans = min(ans, 1LL * min1 * min2); 
    ans = min(ans, 1LL * max1 * max2); 
    cout << ans;
}