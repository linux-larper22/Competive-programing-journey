#include <bits/stdc++.h>
using namespace std;
const int MOD = 123456789;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    map<long long, long long> mp;
    for (int i = 0; i < n; i++) 
    {
        long long x;
        cin >> x;
        for (long long j = 2; j * j <= x; j++) 
        {
            while (x % j == 0) {
                mp[j]++;
                x /= j;
            }
        }
        if (x > 1) mp[x]++;
    }

    long long res = 1;
    for (auto &it : mp) {
        res = res * (it.second + 1) % MOD;
    }

    cout << res;
}