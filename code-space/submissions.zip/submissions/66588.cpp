#include <bits/stdc++.h>
using namespace std;

int main() {
    int n; cin >> n;
    vector<long long> a(n);
    for (auto &x : a) cin >> x;

    long long g = 0;
    for (int i = 1; i < n; i++) {
        g = __gcd(g, abs(a[i] - a[0]));
    }

    if (g == 0) {
        cout << a[0];
    } else {
        cout << g;
    }
}