#include <bits/stdc++.h>
using namespace std;
long long squareFree(long long x) 
{
    long long res = 1;
    for (long long p = 2; p * p <= x; p++) 
    {
        int dem = 0;
        while (x % p == 0) 
        {
            x /= p;
            dem++;
        }
        if (dem % 2 == 1) res *= p;
    }
    if (x > 1) res *= x;
    return res;
}
int main() 
{
    long long L, R;
    cin >> L >> R;
    int n = R - L + 1;
    vector<long long> sf(n);
    for (int i = 0; i < n; i++)
        sf[i] = squareFree(L + i);
    long long demCap = 0;
    for (int i = 0; i < n; i++) 
    {
        for (int j = i + 1; j < n; j++) 
        {
            if (sf[i] == 1 || sf[j] == 1 || sf[i] == sf[j])
                demCap++;
        }
    }
    cout << demCap;
}