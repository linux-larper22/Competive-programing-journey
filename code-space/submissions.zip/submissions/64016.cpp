#include <bits/stdc++.h>
using namespace std;

bool isPrime(int x){
    if(x < 2) return false;
    for(int i=2;i*i<=x;i++)
        if(x%i==0) return false;
    return true;
}

int main(){
    int n, T;
    cin >> n >> T;
    vector<int> a(n);
    for(int &x : a) cin >> x;
    
    vector<int> prime(n);
    for(int i=0;i<n;i++) prime[i] = isPrime(a[i]) ? 1 : 0;
    
    int sum = 0;
    for(int i=0;i<T;i++) sum += prime[i];
    if(sum == 0){ cout << 0; return 0;}
    
    for(int i=T;i<n;i++){
        sum += prime[i] - prime[i-T];
        if(sum==0){ cout << 0; return 0;}
    }
    cout << 1;
}