#include <bits/stdc++.h>
using namespace std;
using int64 = long long;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<int64> a(n);
    for (int i = 0; i < n; i++)
        cin >> a[i];
    sort(a.begin(), a.end());
    int64 pre = 0;
    int64 ans = 0;

    for (int i = 0; i < n; i++) {
        ans += 1LL * i * a[i] - pre;
        pre += a[i];
    }
    cout << ans * 2;
}