#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    long long n,k;
    cin>>n>>k;

    unordered_map<long long,long long> cnt;
    long long ans=0;

    for(int i=0;i<n;i++){
        long long x;
        cin>>x;

        long long r = x%k;
        long long need = (k-r)%k;

        ans += cnt[need];
        cnt[r]++;
    }

    cout<<ans;
}