#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin >> n;
    int a = 0, b = 0;
    for (int i = 1; i <= n; i++) 
    {
        if (i % 2 == 0) {
            a += 2;
            b -= 2;
        } else {
            a += i;
            b += i;
        }
    }
    cout << a << "\n" << b;
}