#include <bits/stdc++.h>
using namespace std;

bool armstrong(int x) {
    int temp = x;

    int k = 0;

    if (x == 0) k = 1;

    while (temp) {
        k++;
        temp /= 10;
    }

    temp = x;

    int sum = 0;

    if (x == 0) sum = 0;

    while (temp) {
        int d = temp % 10;
        sum += pow(d, k);
        temp /= 10;
    }

    return sum == x;
}

int main() {
    freopen("Amstrong.inp", "r", stdin);
    freopen("Amstrong.out", "w", stdout);

    int n;
    cin >> n;

    for (int i = 0; i <= n; i++)
        if (armstrong(i))
            cout << i << '\n';

    return 0;
}