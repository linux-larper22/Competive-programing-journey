#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const ll INF = (ll)4e18;

int n, k;
vector<ll> a, pref, dp_prev, dp_cur;

ll cost(int j, int i, int kk){
    return dp_prev[j] + kk * (pref[i] - pref[j]);
}

void solve(int l, int r, int optL, int optR, int kk){
    if(l > r) return;

    int mid = (l + r) >> 1;

    pair<ll,int> best = {INF, -1};

    for(int j = optL; j <= min(mid-1, optR); j++){
        ll val = cost(j, mid, kk);
        if(val < best.first){
            best = {val, j};
        }
    }

    dp_cur[mid] = best.first;
    int opt = best.second;

    solve(l, mid-1, optL, opt, kk);
    solve(mid+1, r, opt, optR, kk);
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n >> k;

    a.assign(n+1,0);
    pref.assign(n+1,0);

    for(int i=1;i<=n;i++){
        cin >> a[i];
        pref[i] = pref[i-1] + a[i];
    }

    dp_prev.assign(n+1, INF);
    dp_cur.assign(n+1, INF);

    dp_prev[0] = 0;

    for(int kk=1; kk<=k; kk++){
        dp_cur.assign(n+1, INF);
        solve(1, n, 0, n-1, kk);
        dp_prev = dp_cur;
    }

    cout << dp_prev[n];
}