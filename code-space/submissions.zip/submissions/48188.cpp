#include <bits/stdc++.h>
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, k;
    std::cin >> n >> k;
    unordered_map<int, int> last;
    int ketqua = INT_MAX;
    for (int i = 1; i <= n; i++) {
        int x;
        std::cin >> x;
        if (last.count(x)) {
            if (i - last[x] < k) {
                ketqua = min(ketqua, x);
            }
        }
        last[x] = i;
    }
    if (ketqua == INT_MAX) cout << -1;
    else std::cout << ketqua;
}