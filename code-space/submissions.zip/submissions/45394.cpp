#include<bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin>>n;
    while(n--){
        long long x;
        cin>>x; //x = (b*b)*e--> b max --> x*y = x*e = b*b*e*e
        //u = b*b --> x = u*e
        //--> u la uoc chinh phuong
        //b <= e --> b*b*b <= b*b*e = x --> b*b = x/e
        long long ans  = 1;
        for(long long b = 1; b*b*b <= x; b++){
            if(x%(b*b)==0) ans = b;
        }
        //b > e -->  e*e*e < e*b*b = x
        for(long long e = 1; e*e*e < x; e++){
            if(x%e==0){
                long long u = x/e;
                long long b = sqrt(u);
                if(b*b == u) ans = max(ans, b);
            }
        }
        cout<<x/(ans*ans)<<endl;
    }

}