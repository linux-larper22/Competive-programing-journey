#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, k;
    cin >> n >> k;
    string s;
    cin >> s;
    sort(s.begin(), s.end());
    if(s[0] != s[k - 1]) 
    {
        cout << s[k - 1];
        return 0;
    }
    string ans;
    ans += s[0];
    if(k == n) 
    {
        cout << ans;
        return 0;
    }
    if(s[k] != s[n - 1]) 
    {
        for(int i = k; i < n; i++)
            ans += s[i];
    }
    else 
    {
        int rem = n - k;
        int take = (rem + k - 1) / k;

        for(int i = 0; i < take; i++)
            ans += s[k];
    }
    cout << ans;
}