#include <bits/stdc++.h>
using namespace std;
struct Cmp 
{
    bool operator()(const string &a, const string &b) const 
    {
        if (a.size() != b.size())
            return a.size() > b.size();   
        return a > b;                     
    }
};
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int k;
    long long n;
    cin >> k >> n;
    vector<char> d(k);
    for (int i = 0; i < k; i++) cin >> d[i];
    sort(d.begin(), d.end());
    priority_queue<string, vector<string>, Cmp> pq;
    for (char c : d)
        pq.push(string(1, c));
    long long cnt = 0;
    while (!pq.empty()) 
    {
        string cur = pq.top();
        pq.pop();
        cnt++;
        if (cnt == n) 
        {
            cout << cur;
            return 0;
        }
        for (char c : d)
            pq.push(cur + c);
    }
}