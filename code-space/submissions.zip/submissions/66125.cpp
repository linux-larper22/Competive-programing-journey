#include <bits/stdc++.h>
using namespace std;
using ll = long long;

ll C2(ll n) { return n * (n - 1) / 2; }
ll C3(ll n) { return n * (n - 1) * (n - 2) / 6; }

int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int n, q; cin >> n >> q;
    vector<int> a(n+1), even(n+1);

    for (int i = 1; i <= n; i++) 
    {
        cin >> a[i];
        even[i] = even[i-1] + (a[i] % 2 == 0);
    }

    while (q--) {
        int l, r; cin >> l >> r;

        ll e = even[r] - even[l-1];
        ll o = (r - l + 1) - e;

        ll res = C3(e) + C2(o) * e;
        cout << res << "\n";
    }
}