#include <bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T; cin >> T;
    while(T--){
        int n,m,k;
        cin >> n >> m >> k;
        vector<int>a(n), b(m);
        for(int &x:a) cin >> x;
        for(int &x:b) cin >> x;
        sort(a.begin(), a.end());
        sort(b.begin(), b.end());
        int l = 0, r = 2e6, ans = 0;
        auto check = [&](int x)
        {
            int i = 0, j = m-1, cnt = 0;
            while(i < n && j >= 0){
                if(a[i] + b[j] >= x)
                {
                    cnt++;
                    i++;
                    j--;
                } else {
                    i++;
                }
            }
            return cnt >= k;
        };

        while(l <= r){
            int mid = (l + r) / 2;
            if(check(mid)){
                ans = mid;
                l = mid + 1;
            } else r = mid - 1;
        }

        cout << ans << '\n';
    }
}