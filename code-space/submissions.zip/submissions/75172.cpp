#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    long long x, prev;
    cin >> prev;
    int cur = 1;
    int ans = 1;
    for (int i = 2; i <= n; i++) 
    {
        cin >> x;
        if ((prev > 0 && x > 0) || (prev < 0 && x < 0))
            cur++;
        else
            cur = 1;
        ans = max(ans, cur);
        prev = x;
    }
    cout << ans;
}