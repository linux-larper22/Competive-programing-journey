#include <bits/stdc++.h>
using namespace std;
const int N = 1e6+5;
int spf[N];
void sieve(){
    for(int i=2;i<N;i++)
    {
        if(!spf[i]){
            for(int j=i;j<N;j+=i)
                if(!spf[j]) spf[j]=i;
        }
    }
}
int kernel(int x){
    int res = 1;
    while(x > 1){
        int p = spf[x];
        res *= p;
        while(x % p == 0) x /= p;
    }
    return res;
}
int main()
{
    sieve();
    int N, a, b;
    cin >> N >> a >> b;
    unordered_map<int,int> mp;
    for(int i=a;i<=b;i++){
        mp[kernel(i)]++;
    }
    int ans = 0;
    for(auto &p: mp)
        ans = max(ans, p.second);

    cout << ans;
}