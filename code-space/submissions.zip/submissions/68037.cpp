#include <bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T; cin >> T;
    while(T--){
        int n,m,k;
        cin >> n >> m >> k;
        vector<int>a(n), b(m);
        for(int &x:a) cin >> x;
        for(int &x:b) cin >> x;

        sort(a.begin(), a.end());
        sort(b.rbegin(), b.rend());

        int res = INT_MAX;
        for(int i=0;i<k;i++){
            res = min(res, a[i] + b[i]);
        }

        cout << res << '\n';
    }
}