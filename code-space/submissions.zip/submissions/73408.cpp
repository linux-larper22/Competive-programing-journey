#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long X, Y, Z;
    cin >> X >> Y >> Z;
    long long need = (X - Y) * Z;
    long long ans = (need + Y - 1) / Y;
    cout << ans;
}