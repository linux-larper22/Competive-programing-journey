#include <bits/stdc++.h>
using namespace std;
bool isPal(string s) 
{
    int l = 0, r = s.size() - 1;
    while (l < r) {
        if (s[l] != s[r]) return false;
        l++; r--;
    }
    return true;
}
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int T;
    cin >> T;
    while (T--) 
    {
        string s;
        cin >> s;
        if (isPal(s)) 
        {
            cout << "YES\n";
            continue;
        }
        int l = 0, r = s.size() - 1;
        while (l < r && s[l] == s[r]) 
        {
            l++; r--;
        }
        string t = s;
        reverse(t.begin() + l, t.begin() + r + 1);

        if (isPal(t)) cout << "YES\n";
        else cout << "NO\n";
    }
}