#include <bits/stdc++.h>
using namespace std;
bool prime(long long x)
{
    if(x<2) return false;
    for(long long i=2;i*i<=x;i++)
        if(x%i==0) return false;
    return true;
}
int main()
{
    int n;
    cin>>n;
    vector<long long>a(n);
    for(int i=0;i<n;i++) cin>>a[i];
    long long ans=0;
    for(int i=0;i<n;i++)
        for(int j=i+1;j<n;j++)
            if(prime(a[i]+a[j]))
                ans++;

    cout<<ans;
}