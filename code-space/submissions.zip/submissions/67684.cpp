#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
    vector<int> a(n);
    for (int &x : a) cin >> x;
    unordered_map<int, int> cnt;
    long long ans = 0;
    vector<int> special;
    for (int d = 1; d <= 9; d++) 
    {
        int num = d;
        while (num <= 2000000) {
            special.push_back(num);
            num = num * 10 + d;
        }
    }
    for (int i = 0; i < n; i++) 
    {
        for (int x : special) {
            int need = x - a[i];
            if (cnt.count(need)) 
            {
                ans += cnt[need];
            }
        }
        cnt[a[i]]++;
    }

    cout << ans;
}