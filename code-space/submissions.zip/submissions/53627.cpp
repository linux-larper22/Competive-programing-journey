#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int soLuong;
    cin >> soLuong;
    unordered_map<long long, int> tanSuat;
    for (int i = 0; i < soLuong; i++) 
    {
        long long giaTri;
        cin >> giaTri;
        tanSuat[giaTri]++;
    }
    int tanSuatMax = 0;
    for (auto &p : tanSuat)
        tanSuatMax = max(tanSuatMax, p.second);
    long long tong = 0;
    for (auto &p : tanSuat)
        if (p.second == tanSuatMax)
            tong += p.first;
    cout << tong;
}