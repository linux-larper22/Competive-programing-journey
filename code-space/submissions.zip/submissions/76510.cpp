#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<int> a(n);
    map<int,int> total;
    vector<map<int,int>> cnt(n);
    for(int i = 0; i < n; i++) 
        {
        cin >> a[i];
        int x = a[i];
        for(int p = 2; p * p <= x; ++p) 
        {
            while(x % p == 0) 
            {
                cnt[i][p]++;
                total[p]++;
                x /= p;
            }
        }
        if(x > 1) 
        {
            ++cnt[i][x];
            ++total[x];
        }
    }
    long long d = 1;
    long long c = 0;
    for(auto [p, E] : total) 
    {
        int need = E / n;
        for(int i = 0; i < need;++i)
            d *= p;
        for(int i = 0; i < n;++i) 
        {
            int have = 0;
            auto it = cnt[i].find(p);
            if(it != cnt[i].end())
                have = it->second;
            if(have < need)
                c += need - have;
        }
    }
    cout << d << ' ' << c;
}