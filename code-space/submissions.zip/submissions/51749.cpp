#include <bits/stdc++.h>
using namespace std;
int main() 
{
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int a, b;
    cin >> a >> b;
    vector<int> sumDiv(b + 1, 0);
    for (int i = 1; i <= b / 2; i++) 
    {
        for (int j = i * 2; j <= b; j += i) 
        {
            sumDiv[j] += i;
        }
    }
    int cnt = 0;
    for (int i = a; i <= b; i++) 
    {
        if (sumDiv[i] > i) cnt++;
    }
    cout << cnt;
}