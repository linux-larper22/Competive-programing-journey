#include <bits/stdc++.h>
using namespace std;
int main() 
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, i;
    cin >> n;
    vector<long long> a(n + 1);
    for (int j = 1; j <= n; j++) cin >> a[j];
    cin >> i;
    long long max_even = LLONG_MIN;
    long long max_odd = LLONG_MIN;
    for (int j = 1; j < i; j++) 
    {
        if (a[j] % 2 == 0) max_even = max(max_even, a[j]);
        else max_odd = max(max_odd, a[j]);
    }
    if (a[i] % 2 == 0) 
    {
        if (max_odd == LLONG_MIN) cout << "IMPOSSIBLE";
        else cout << a[i] + max_odd;
    } else {
        if (max_even == LLONG_MIN) cout << "IMPOSSIBLE";
        else cout << a[i] + max_even;
    }
    return 0;
}